---
title: Coding for kids for dummies
taxonomy:
	author: Camille,McCue
	pubdate: 2015
	audience: 
	expertise: 
---
## Coding for kids for dummies
### By Camille,McCue

**Publication Date:** 2015

**ISBN:** 1-118-94032-6