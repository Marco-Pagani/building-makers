---
title: Elements of Photogrammetry with Application in GIS
taxonomy:
	author: Benjamin E.,Bon A.; Wilkinson,Paul R.; Dewitt,Wolf
	pubdate: 2014
	audience: 
	expertise: 
---
## Elements of Photogrammetry with Application in GIS
### By Benjamin E.,Bon A.; Wilkinson,Paul R.; Dewitt,Wolf

**Publication Date:** 2014

**ISBN:** 0071761128 (hbk.)