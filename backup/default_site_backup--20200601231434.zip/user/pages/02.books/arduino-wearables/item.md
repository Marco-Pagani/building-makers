---
title: Arduino wearables
taxonomy:
	author: Tony Olsson
	pubdate: 2012
	audience: K-12,Libraries,College/University,General
	expertise: Beginner,Intermediate
---
## Arduino wearables
### By Tony Olsson
UF lib - QA76.592.O47 2012 

**Publication Date:** 2012

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** K-12,Libraries,College/University,General

**ISBN:** 978-1430243595

[Amazon Link](https://www.amazon.com/Arduino-Wearables-Technology-Action-Olsson/dp/1430243597)