---
title: Exploring Raspberry Pi: Interfacing to the Real World with Embedded Linux
taxonomy:
	author: Derek,Molloy
	pubdate: 2016
	audience: 
	expertise: 
---
## Exploring Raspberry Pi: Interfacing to the Real World with Embedded Linux
### By Derek,Molloy

**Publication Date:** 2016

**ISBN:** 978-1-119-18870-4