---
title: 3d printing for dummies
taxonomy:
	author: Richard; ebrary.,Kirk Kalani; Horne,Hausman
	pubdate: 2014
	audience: General
	expertise: Beginner
---
## 3d printing for dummies
### By Richard; ebrary.,Kirk Kalani; Horne,Hausman
This book is designed to teach you the basics of 3D Printing and is perfect for beginners.  It discusses the basics of 3D Printing, deciding what materials and printer to use, and the applications of 3D Printing.  These include art, manufacturing, and even food production.

**Publication Date:** 2014

**Expertise Level:** Beginner

**Intended Audience:** General

**ISBN:** 9781118660683 (e-book)

[Amazon Link](https://www.amazon.com/Printing-Dummies-Kalani-Kirk-Hausman/dp/1118660757/ref=sr_1_5?keywords=3D+printing+for+dummies&qid=1569256815&s=gateway&sr=8-5)

[Worldcat Link](https://www.worldcat.org/title/3d-printing-for-dummies/oclc/900057826&referer=brief_results)