---
title: 3D Modeling : 21st Century Skills Innovation Library
taxonomy:
	author: Theo Zizka
	pubdate: 2014
	audience: K-12
	expertise: Beginner
---
## 3D Modeling : 21st Century Skills Innovation Library
### By Theo Zizka
This book explores the basics of 3D modeling using the free SketchUp software.  It also suggests ways to  further develop your 3D modeling skills once you finish the book.

**Publication Date:** 2014

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 9781631378126 1631378120

[Amazon Link](https://www.amazon.com/Modeling-Century-Skills-Innovation-Library/dp/1631377922/ref=sr_1_1?keywords=3D+Modeling+%3A+21st+Century+Skills+Innovation+Library&qid=1575300157&sr=8-1 )

[Worldcat Link](https://www.worldcat.org/title/3d-modeling-21st-century-skills-innovation-library/oclc/963796740&referer=brief_results)