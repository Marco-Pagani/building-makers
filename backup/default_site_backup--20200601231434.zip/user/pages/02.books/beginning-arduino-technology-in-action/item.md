---
title: Beginning Arduino (Technology in Action)
taxonomy:
	author: Michael McRoberts
	pubdate: 2013
	audience: Libraries,College/University,General,K-12
	expertise: Beginner,Intermediate
---
## Beginning Arduino (Technology in Action)
### By Michael McRoberts
UF - TK7835.M37 2013

**Publication Date:** 2013

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** Libraries,College/University,General,K-12

**ISBN:** 978-1430250166

[Amazon Link](https://www.amazon.com/Beginning-Arduino-Technology-Michael-McRoberts/dp/143025016X)