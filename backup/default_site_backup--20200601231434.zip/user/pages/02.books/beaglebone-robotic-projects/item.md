---
title: BeagleBone Robotic Projects.
taxonomy:
	author: Richard,Grimmett
	pubdate: 2013
	audience: General
	expertise: Intermediate,Beginner
---
## BeagleBone Robotic Projects.
### By Richard,Grimmett
Each chapter of this book guides you through a project aimed to get you comfortable with the BeagleBone board.  As you progress through the chapters you learn more advanced skills with the BeagleBone, like connecting a remote control and a GPS.  These projects will help you build some of the skills necessary to create whatever your heart desires with BeagleBone.

**Publication Date:** 2013

**Expertise Level:** Intermediate,Beginner

**Intended Audience:** General

**ISBN:** 1-306-28021-4

[Amazon Link](https://www.amazon.com/BeagleBone-Robotic-Projects-Richard-Grimmett/dp/1783559322/ref=sr_1_2?keywords=BeagleBone+Robotic+Projects.&qid=1570650412&sr=8-2)

[Worldcat Link](https://www.worldcat.org/title/beaglebone-robotic-projects-create-complex-and-exciting-robotic-projects-with-the-beaglebone-blue/oclc/990752523&referer=brief_results)