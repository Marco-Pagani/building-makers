---
title: 3D animation for the raw beginner using Autodesk Maya 2nd edition
taxonomy:
	author: Roger (Roger Alan),King
	pubdate: 2019
	audience: 
	expertise: 
---
## 3D animation for the raw beginner using Autodesk Maya 2nd edition
### By Roger (Roger Alan),King

**Publication Date:** 2019

**ISBN:** 0-8153-8878-0