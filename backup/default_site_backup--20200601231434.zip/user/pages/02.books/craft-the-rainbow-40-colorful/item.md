---
title: "Craft the rainbow : 40 colorful paper projects from ""The house that Lars built"""
taxonomy:
	author: Chaunte,; Vaugh,Darcy,; Miller,Brittany Watson,Jepsen
	pubdate: 2018
	audience: General
	expertise: Intermediate
---
## "Craft the rainbow : 40 colorful paper projects from ""The house that Lars built"""
### By Chaunte,; Vaugh,Darcy,; Miller,Brittany Watson,Jepsen
This beautifully designed book includes step by step instructions in numerous paper crafts, including but not limited to floral wreaths, shoe clips,  a curtain tassels, tissue paper rugs, and more.  The main focus of this book is the celebration of each color of the rainbow through the crafts included.  The techniques range from simple folding and glueing to more complex projects, paper crafters seasoned and novice can enjoy the crafts offered in this book.

**Publication Date:** 2018

**Expertise Level:** Intermediate

**Intended Audience:** General

**ISBN:** 978-1-4197-2900-3 1-4197-2900-4

[Amazon Link]("https://www.amazon.com/s?k=Craft+the+rainbow+%3A+40+colorful+paper+projects+from+""The+house+that+Lars+built""&ref=nb_sb_noss")

[Worldcat Link](https://www.worldcat.org/title/craft-the-rainbow-40-colorful-paper-projects-from-the-house-that-lars-built/oclc/1000583372&referer=brief_results)