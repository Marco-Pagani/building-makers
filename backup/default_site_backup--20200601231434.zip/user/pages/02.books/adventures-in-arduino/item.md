---
title: Adventures in Arduino
taxonomy:
	author: Becky Stewart
	pubdate: 2015
	audience: K-12
	expertise: Beginner
---
## Adventures in Arduino
### By Becky Stewart
UF Lib - TJ223.P76

**Publication Date:** 2015

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1118948477

[Amazon Link](https://www.amazon.com/Adventures-Arduino-Becky-Stewart/dp/1118948475/ref=sr_1_1?ie=UTF8&qid=1541632403&sr=8-1&keywords=adventures+in+arduino&dpID=51kUEtA7W4L&preST=_SX258_BO1,204,203,200_QL70_&dpSrc=srch)