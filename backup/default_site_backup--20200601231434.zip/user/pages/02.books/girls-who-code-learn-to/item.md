---
title: Girls who code : learn to code and change the world
taxonomy:
	author: Andrea,Reshma; Tsurumi,Saujani
	pubdate: 2017
	audience: General,K-12
	expertise: Beginner
---
## Girls who code : learn to code and change the world
### By Andrea,Reshma; Tsurumi,Saujani
This book is dedicated to empowering girls and women to code, but it can be used by anyone who wishes to develop coding skills.  It is simple and accessible, with illustrations and easy to follow explanations of coding. It also includes stories with five girls who have created websites, games and more by learning to code.

**Publication Date:** 2017

**Expertise Level:** Beginner

**Intended Audience:** General,K-12

**ISBN:** 0-425-28753-X

[Amazon Link](https://www.amazon.com/Girls-Who-Code-Learn-Change/dp/042528753X/ref=sr_1_1?keywords=Girls+who+code+%3A+learn+to+code+and+change+the+world&qid=1573573933&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/girls-who-code-learn-to-code-and-change-the-world/oclc/1019882943&referer=brief_results)