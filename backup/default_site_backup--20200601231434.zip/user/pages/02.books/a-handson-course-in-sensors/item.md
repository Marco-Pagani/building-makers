---
title: A Hands-On Course in Sensors Using the Arduino and Raspberry Pi
taxonomy:
	author: Volker Ziemann
	pubdate: 2018
	audience: 
	expertise: 
---
## A Hands-On Course in Sensors Using the Arduino and Raspberry Pi
### By Volker Ziemann

**Publication Date:** 2018