---
title: Arduino for Dummies.
taxonomy:
	author: John; ProQuest (Firm),Consumer; Nussey,Dummies
	pubdate: 2018
	audience: General
	expertise: Beginner,Intermediate
---
## Arduino for Dummies.
### By John; ProQuest (Firm),Consumer; Nussey,Dummies
This book will be helpful for beginners, hobbyists, and more experienced electronics enthusiasts.  It includes instructions in a number of Arduino functions, including blinking LEDs, creating an Arduino sketch, and some basics of processing.

**Publication Date:** 2018

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** General

**ISBN:** 978-1-119-48954-2

[Amazon Link](https://www.amazon.com/Arduino-Dummies-Computer-Tech/dp/1119489547/ref=sr_1_3?keywords=arduino+for+dummies&qid=1574350591&sr=8-3)

[Worldcat Link](https://www.worldcat.org/title/arduino-for-dummies/oclc/1048924447&referer=brief_results)