---
title: Creating the character costume : tools, tips, and talks with top costumers and cosplayers
taxonomy:
	author: Cheralyn; ProQuest (Firm),Lambeth
	pubdate: 2017
	audience: General
	expertise: Beginner
---
## Creating the character costume : tools, tips, and talks with top costumers and cosplayers
### By Cheralyn; ProQuest (Firm),Lambeth
"Whether you want to design an  unforgettable halloween costume or you are designing a character costume for a play or convention, ""Creating the character costume : tools, tips, and talks with top costumers and cosplayers"" is here to help.  It walks you through the thought processes every costume designer must go through: what kind of fabric should you use, how will you fit your costume to the model, how long does your costume need to last.  It includes tips from costumers to help you make your costume goals a reality."

**Publication Date:** 2017

**Expertise Level:** Beginner

**Intended Audience:** General

**ISBN:** 1-138-81611-6

[Amazon Link](https://www.amazon.com/Creating-Character-Costume-Costumers-Cosplayers/dp/1138472921/ref=sr_1_1?keywords=Creating+the+character+costume+%3A+tools%2C+tips%2C+and+talks+with+top+costumers+and+cosplayers&qid=1570650158&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/creating-the-character-costume-tools-tips-and-talks-with-top-costumers-and-cosplayers/oclc/1019620569&referer=brief_results)