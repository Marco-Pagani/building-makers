---
title: Food photography : a beginner's guide to creating appetizing images
taxonomy:
	author: Corinna,Gissemann
	pubdate: 2016
	audience: General
	expertise: Intermediate
---
## Food photography : a beginner's guide to creating appetizing images
### By Corinna,Gissemann
Food photography : a beginners guide to creating appetizing images covers the basics like choosing your camera and using the right settings.  It also teaches you more advanced aspects of food photography, like staging, angles, props, and editing your pictures.  This book is for those who want to show off their food with high quality photos.

**Publication Date:** 2016

**Expertise Level:** Intermediate

**Intended Audience:** General

**ISBN:** 1-68198-101-7

[Amazon Link](https://www.amazon.com/Food-Photography-Beginners-Guide-Creating-Appetizing/dp/1681981017/ref=sr_1_1?keywords=Food+Photography%3A+A+Beginner%27s+Guide+to+Creating+Appetizing+Images&qid=1570465667&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/food-photography-a-beginners-guide-to-creating-appetizing-images/oclc/951124639&referer=brief_results)