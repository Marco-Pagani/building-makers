---
title: 3D printing : technology, applications, and selection
taxonomy:
	author: Rafiq,Noorani
	pubdate: 2017
	audience: General
	expertise: Intermediate
---
## 3D printing : technology, applications, and selection
### By Rafiq,Noorani
3D printing : technology, applications, and selection covers how 3D printers are made, how they work, and what they can be used for.  This is a great book for anyone who wants to learn more about 3D printing as a tool.

**Publication Date:** 2017

**Expertise Level:** Intermediate

**Intended Audience:** General

**ISBN:** 10.1201/9781315155494 doi

[Amazon Link](https://www.amazon.com/3D-Printing-Technology-Applications-Selection/dp/1498783759/ref=sr_1_2?keywords=3D+printing+%3A+technology%2C+applications%2C+and+selection&qid=1569590604&s=gateway&sr=8-2)

[Worldcat Link](https://www.worldcat.org/title/3d-printing-technology-applications-and-selection/oclc/1021403874&referer=brief_results)