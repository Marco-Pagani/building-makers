---
title: ESP8266 home automation projects : leverage the power of this tiny WiFi chip to build exciting smart home projects
taxonomy:
	author: Catalin.,Batrinu
	pubdate: 2017
	audience: 
	expertise: 
---
## ESP8266 home automation projects : leverage the power of this tiny WiFi chip to build exciting smart home projects
### By Catalin.,Batrinu

**Publication Date:** 2017