<?php
// Deprecated.

require_once __DIR__ . '/../classes/Twig/AdminTwigExtension.php';

class_alias('Grav\Plugin\Admin\Twig\AdminTwigExtension', 'Grav\Plugin\Admin\AdminTwigExtension');
