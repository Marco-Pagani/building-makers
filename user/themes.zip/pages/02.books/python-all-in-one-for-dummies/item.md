---
title: Python All-in-One For Dummies
taxonomy:
	author: [John Shovic, Alan Simpson]
	pubdate: 2019
	isbn: 1119557593
	subjects: [Programming]
	audience: [General]
	expertise: [Beginner, Intermediate]
publisher: John Wiley & Sons
pagecount: 704
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Python-All-One-Dummies-Shovic/dp/1119557593/ref=sr_1_1?keywords=Python+all-in-one&qid=1575492272&sr=8-1
worldcat: https://www.worldcat.org/title/python-all-in-one/oclc/1122746992&referer=brief_results
google: https://play.google.com/store/books/details?id=BDmRDwAAQBAJ
---
This easy-to-read book is a great introduction to the Python coding language and covers many of the skills you will need to use Python, like entering commends, sidestepping errors, and managing your python files.  It also dives into artificial intelligence and robotics, two important applications of python.