---
title: Alexa For Dummies
taxonomy:
	author: [Paul McFedries]
	pubdate: 2018
	isbn: 1119565812
	subjects: [Internet of Things]
	audience: [General]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: John Wiley & Sons
pagecount: 304
thumb: small.jpeg
cover: medium.jpeg
amazon: https://www.amazon.com/Alexa-Dummies-Paul-McFedries/dp/1119565863/ref=sr_1_1?keywords=Alexa+for+Dummies.&qid=1575492538&sr=8-1
worldcat: https://www.worldcat.org/title/alexa-for-dummies/oclc/1083268734&referer=brief_results
google: https://play.google.com/store/books/details?id=yGd-DwAAQBAJ
---
Alexa for Dummies is your guide to understanding and using your Alexa to enhance your home.  It covers the basic functions of Alexa as well as adding to her skills and connecting her to smart home devices.