---
title: Rad Recycled Art
taxonomy:
	author: [Emily Kington]
	pubdate: 2019
	isbn: 1541548493
	subjects: []
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Hungry Tomato ®
pagecount: 32
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Rad-Recycled-Art-Wild-Projects-ebook/dp/B07JK6HQMQ/ref=sr_1_1?keywords=Rad+recycled+art&qid=1570114220&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/rad-recycled-art/oclc/1099594168&referer=brief_results
google: https://play.google.com/store/books/details?id=dsJ9DwAAQBAJ
---
The book contains craft projects made from recycled easily available household material. Each project contains detailed instructions and a list of materials required. The goal of every project is to develop something that could be used in everyday life and also looks colorful and quirky.