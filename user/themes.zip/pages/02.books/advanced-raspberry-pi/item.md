---
title: Advanced Raspberry Pi: Raspbian Linux and GPIO Integration
taxonomy:
	author: [Warren Gay]
	pubdate: 2018
	isbn: 1484239482
	subjects: [Raspberry Pi's]
	audience: [General]
	expertise: [Intermediate, Advanced]
publisher: Apress
pagecount: 521
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Advanced-Raspberry-Pi-Raspbian-Integration/dp/1484239474/ref=sr_1_3?keywords=Advanced+Raspberry+Pi%3A+Raspbian+Linux+and+GPIO+Integration&qid=1570651464&sr=8-3
worldcat: https://www.worldcat.org/title/advanced-raspberry-pi-raspbian-linux-and-gpio-integration/oclc/1117843596&referer=brief_results
google: https://play.google.com/store/books/details?id=Ks10DwAAQBAJ
---
Advanced Raspberry Pi: Raspbian Linux and GPIO Integration introduces you to Raspberry Pi and provides detailed explanations of the functions of your Raspberry Pi, simple and advanced.