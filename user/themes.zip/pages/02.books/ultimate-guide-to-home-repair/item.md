---
title: Ultimate Guide to Home Repair and Improvement, Updated Edition: Proven Money-Saving Projects; 3,400 Photos and Illustrations
taxonomy:
	author: [Editors of Creative Homeowner]
	pubdate: 2016
	isbn: 158011783X
	subjects: [Hand Tools]
	audience: [General]
	expertise: [Advanced]
publisher: Creative Homeowner
pagecount: 600
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Ultimate-Guide-Repair-Improvement-Updated/dp/158011783X/ref=sr_1_3?keywords=Ultimate+guide+home+repair+and+improvement&qid=1570112105&s=gateway&sr=8-3
worldcat: https://www.worldcat.org/title/ultimate-guide-home-repair-and-improvement/oclc/959029423&referer=brief_results
google: https://play.google.com/store/books/details?id=8RISjwEACAAJ
---
The book provides detailed instruction on mending common household damages. It provides illustrated guidance on household repairs on an exhaustive list of damages and construction works. It also includes a comprehensive list of materials required for completing the tasks.