---
title: Food Photography: A Beginners Guide to Creating Appetizing Images
taxonomy:
	author: [Corinna Gissemann]
	pubdate: 2016
	isbn: 1681981017
	subjects: [Photography & Video, Photography]
	audience: [General]
	expertise: [Intermediate]
cover: http://books.google.com/books/content?id=Xj9ZjwEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
amazon: https://www.amazon.com/Food-Photography-Beginners-Guide-Creating-Appetizing/dp/1681981017/ref=sr_1_1?keywords=Food+Photography%3A+A+Beginner%27s+Guide+to+Creating+Appetizing+Images&qid=1570465667&sr=8-1
worldcat: https://www.worldcat.org/title/food-photography-a-beginners-guide-to-creating-appetizing-images/oclc/951124639&referer=brief_results
google: https://books.google.com/books/about/Food_Photography.html?hl=&id=Xj9ZjwEACAAJ
---
Food photography : a beginners guide to creating appetizing images covers the basics like choosing your camera and using the right settings.  It also teaches you more advanced aspects of food photography, like staging, angles, props, and editing your pictures.  This book is for those who want to show off their food with high quality photos.