---
title: Tapestry Weaving
taxonomy:
	author: [Kirsten Glasbrook]
	pubdate: 2015
	isbn: 1782212043
	subjects: [Sewing]
	audience: [General]
	expertise: [Advanced]
publisher: Search Press Limited
pagecount: 96
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Tapestry-Weaving-Search-Press-Classics/dp/1782212043/ref=sr_1_1?keywords=Tapestry+weaving&qid=1570113639&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/tapestry-weaving/oclc/991529810&referer=brief_results
google: https://play.google.com/store/books/details?id=H7eQrgEACAAJ
---
The book gives detailed project instructions on tapestry weaving. It provides instructions on basic techniques like wefts, warps, hatching and slits. Along with the instructions, there is a gallery of ideas and designs to practice from. The book also provides instructions on mounting and framing.