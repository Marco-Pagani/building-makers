---
title: Code It! Create It!: Ideas and Inspiration for Coding
taxonomy:
	author: [Sarah Hutt]
	pubdate: 2017
	isbn: 9780399542558
	subjects: [Computer Programming]
	audience: []
	expertise: []
cover: http://books.google.com/books/content?id=7-U3DwAAQBAJ&printsec=frontcover&img=1&zoom=1&edge=curl&source=gbs_api
amazon: nil
worldcat: nil
google: https://books.google.com/books/about/Code_It_Create_It.html?hl=&id=7-U3DwAAQBAJ
---
Girls can design the perfect coding-powered project for themselves in this informative, interactive book published in partnership with the nonprofit organization Girls Who Code that guides readers through the brainstorming process, provides inspiration, and teaches basic coding concepts. Illustrations. Consumable.