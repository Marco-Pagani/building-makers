---
title: Organizing a MakerFest
taxonomy:
	author: [Kristin Fontichiaro]
	pubdate: 2017
	isbn: 1634722566
	subjects: [Makerspaces - Operating]
	audience: [K-12]
	expertise: [Intermediate]
publisher: Cherry Lake
pagecount: 24
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Organizing-Makerfest-Makers-as-Innovators/dp/1634723228
worldcat: https://www.worldcat.org/title/organizing-a-makerfest/oclc/967683438&referer=brief_results
google: https://play.google.com/store/books/details?id=4_JKDQAAQBAJ
---
This book is meant to inform children about what Makerfests are and how they can help organize and run a Makerfest with the help of trusted adults.  It includes setting up, finding volunteers to help run maker stations and more.