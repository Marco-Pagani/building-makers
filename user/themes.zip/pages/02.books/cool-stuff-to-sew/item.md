---
title: Cool Stuff to Sew
taxonomy:
	author: [Stephanie Turnbull]
	pubdate: 2019
	isbn: 1445141752
	subjects: [Sewing]
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Hachette Children's Group
pagecount: 32
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Sewing-Try-This-Stephanie-Turnbull/dp/1625883757/ref=sr_1_1?keywords=sewing+turnbull&qid=1571174703&sr=8-1
worldcat: worldcat.org/title/sewing/oclc/910531136&referer=brief_results
google: https://play.google.com/store/books/details?id=uv2qtgEACAAJ
---
This easy-to-read book features colorful illustrations and clear instructions teaching basic sewing. It also includes 7 projects perfect to complete in a classroom or at home.