---
title: Hemp Bracelets and More: Easy Instructions for More Than 20 Designs
taxonomy:
	author: [Suzanne McNeill]
	pubdate: 2016
	isbn: 1607654660
	subjects: []
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Fox Chapel Publishing
pagecount: 250
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Tandy-Leather-Hemp-Bracelets-61964-00/dp/1497200571/ref=sr_1_1?keywords=Hemp+bracelets+and+more+%3A+easy+instructions+for+more+than+20+designs&qid=1570112789&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/hemp-bracelets-and-more-easy-instructions-for-more-than-20-designs/oclc/929585526&referer=brief_results
google: https://play.google.com/store/books/details?id=PqV8DwAAQBAJ
---
The book provides instruction on hemp bracelet projects with detailed, illustrated instructions on overhand knots, half-hitch knot, half knot, square knot and josephine knot. It starts with different ideas for bracelets and strategies for projects and knitting.