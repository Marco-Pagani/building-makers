---
title: Scratch Code Smart Homes
taxonomy:
	author: [Max Wainewright]
	pubdate: 2019
	isbn: 0778765407
	subjects: [Internet of Things]
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Crabtree Publishing Company
pagecount: 32
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Scratch-Code-Smart-Homes-Challenge/dp/0778765687/ref=sr_1_1?keywords=smart+homes+wainewright+max&qid=1575245907&sr=8-1
worldcat: https://www.worldcat.org/title/scratch-code-smart-homes/oclc/1090700944&referer=brief_results
google: https://play.google.com/store/books/details?id=5RmiwwEACAAJ
---
Using Scratch 3, a free online program for coding, this book explains some of the technologies used in smart home technologies, like cameras, voice control, and alarms using colorful diagrams and step by step projects.