---
title: AutoCAD 2019 Beginning and Intermediate
taxonomy:
	author: [Munir Hamad]
	pubdate: 2018
	isbn: 1683921771
	subjects: [3D Modeling]
	audience: [College/University, Libraries]
	expertise: [Intermediate]
publisher: Stylus Publishing LLC
pagecount: 800
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/AutoCAD-2019-Modeling-Munir-Hamad-ebook/dp/B07FKQSFJ6/ref=sr_1_9?keywords=AutoCAD+2019%3A+3D+Modeling&qid=1569589687&s=gateway&sr=8-9
worldcat: https://www.worldcat.org/title/autocad-2019-3d-modeling/oclc/1038803522&referer=brief_results
google: https://play.google.com/store/books/details?id=qzFfDwAAQBAJ
---
AutoCAD 2019: 3D Modeling covers everything from the basics of AutoCAD like how to view a design in a 3 dimensional plain to designing different kinds of surfaces to assigning materials to your design to animating or printing your design.