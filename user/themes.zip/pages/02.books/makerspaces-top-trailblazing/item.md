---
title: Makerspaces: Top Trailblazing Projects, A LITA Guide
taxonomy:
	author: [Caitlin A. Bagley]
	pubdate: 2014
	isbn: 1555709907
	subjects: [Making Scholarship, Makerspaces - Operating]
	audience: [College/University, Libraries]
	expertise: [Advanced]
publisher: American Library Association
pagecount: 128
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Makerspaces-Trailblazing-Projects-LITA-Guide-ebook/dp/B00JLQTIHK/ref=sr_1_1?keywords=Makerspaces+%3A+top+trailblazing+projects&qid=1569877251&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/makerspaces-top-trailblazing-projects/oclc/937883152&referer=brief_results
google: https://play.google.com/store/books/details?id=UumkAwAAQBAJ
---
The book provides information on Makerspace and its different uses and applications. It then provides a detailed description and analysis of some of the most successful makerspace projects at both academic and public libraries. It provides useful information which readers can apply to their own institutions.