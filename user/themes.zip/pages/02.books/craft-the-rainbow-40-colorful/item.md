---
title: Craft the Rainbow: 40 Colorful Paper Projects from The House That Lars Built
taxonomy:
	author: [Brittany Watson Jepsen]
	pubdate: 2018
	isbn: 1683352157
	subjects: [Paper Crafts]
	audience: [General]
	expertise: [Intermediate]
	tag: [lesson plans]
publisher: Abrams
pagecount: 192
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/s?k=Craft+the+rainbow+%3A+40+colorful+paper+projects+from+"The+house+that+Lars+built"&ref=nb_sb_noss
worldcat: https://www.worldcat.org/title/craft-the-rainbow-40-colorful-paper-projects-from-the-house-that-lars-built/oclc/1000583372&referer=brief_results
google: https://play.google.com/store/books/details?id=JM1FDwAAQBAJ
---
This beautifully designed book includes step by step instructions in numerous paper crafts, including but not limited to floral wreaths, shoe clips,  a curtain tassels, tissue paper rugs, and more.  The main focus of this book is the celebration of each color of the rainbow through the crafts included.  The techniques range from simple folding and glueing to more complex projects, paper crafters seasoned and novice can enjoy the crafts offered in this book.