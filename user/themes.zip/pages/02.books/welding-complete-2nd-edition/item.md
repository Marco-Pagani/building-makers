---
title: Welding Complete, 2nd Edition: Techniques, Project Plans & Instructions
taxonomy:
	author: [Michael A. Reeser]
	pubdate: 2017
	isbn: 0760357749
	subjects: [Hand Tools]
	audience: []
	expertise: []
publisher: Cool Springs Press
pagecount: 240
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Welding-Complete-2nd-Techniques-Instructions/dp/159186691X/ref=sr_1_2?keywords=Welding+complete+%3A+techniques%2C+project+plans+%26+instructions&qid=1571081471&sr=8-2
worldcat: https://www.worldcat.org/title/welding-complete-techniques-project-plans-instructions/oclc/960836664&referer=brief_results
google: https://play.google.com/store/books/details?id=eLktDwAAQBAJ
---
Welding complete begins by discussing the basics of welding and then outlines projects you can complete to serve any purpose, including building your own welding table, wine rack, or fence.