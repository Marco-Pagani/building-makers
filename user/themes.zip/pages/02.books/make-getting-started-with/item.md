---
title: Make: Getting Started with Arduino: The Open Source Electronics Prototyping Platform
taxonomy:
	author: [Massimo Banzi, Michael Shiloh]
	pubdate: 2014
	isbn: 1449363334
	subjects: [Arduinos, Computers]
	audience: []
	expertise: []
cover: http://books.google.com/books/content?id=nYLmoAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
amazon: nil
worldcat: http://www.worldcat.org/oclc/904719184
google: https://books.google.com/books/about/Make_Getting_Started_with_Arduino.html?hl=&id=nYLmoAEACAAJ
---
Presents an introduction to the open-source electronics prototyping platform.