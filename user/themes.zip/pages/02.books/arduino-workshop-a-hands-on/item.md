---
title: Arduino Workshop: A Hands-on Introduction with 65 Projects
taxonomy:
	author: [John Boxall]
	pubdate: 2013
	isbn: 1593274483
	subjects: [Arduinos]
	audience: [General, College/University, Libraries]
	expertise: [Beginner, Intermediate]
	tag: [lesson plans]
publisher: No Starch Press
pagecount: 392
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Arduino-Workshop-Hands-Introduction-Projects/dp/1593274483/ref=sr_1_1?keywords=Arduino+workshop%3A+a+hands-on+introduction+with+65+projects&qid=1569591579&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/arduino-workshop-a-hands-on-introduction-with-65-projects/oclc/940823119&referer=brief_results
google: https://play.google.com/store/books/details?id=PUm8tCA6L-kC
---
Arduino workshop" briefly discusses the basics of Arduino and then covers many applications and additions that enhance your use of your Arduino.  This would be helpful for someone who has already tried using an Arduino who is interested in advancing their knowledge.