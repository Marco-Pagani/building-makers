---
title: I Can Make Remarkable Robots
taxonomy:
	author: [Kristina A. Holzweiss, Amy Barth]
	pubdate: 2017
	isbn: 053123410X
	subjects: [Robotics]
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Scholastic Incorporated
pagecount: 32
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: nil
worldcat: nil
google: https://play.google.com/store/books/details?id=q0R4AQAACAAJ
---
This fun and colorful book contains 3 projects to teach your child the basics of robotics.  Each project includes a materials list, background information, and step by step instructions and pictures to guide you and your child to the finished product.