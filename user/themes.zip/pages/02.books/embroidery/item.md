---
title: Embroidery
taxonomy:
	author: [Dorling Kindersley, Inc.]
	pubdate: 2015
	isbn: 1465436030
	subjects: [Sewing]
	audience: [General]
	expertise: [Beginner, Advanced, Intermediate]
publisher: DK
pagecount: 160
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Embroidery-Step-Step-Guide-Stiches/dp/1465436030/ref=sr_1_1?keywords=embroidery+lucinda+ganderton&qid=1571939665&sr=8-1
worldcat: https://www.worldcat.org/title/embroidery-a-step-by-step-guide-to-more-than-200-stitches/oclc/972361579&referer=brief_results
google: https://play.google.com/store/books/details?id=3qjAoQEACAAJ
---
This book starts by introducing the tools you will need to create beautiful embroidery.  It follows with illustrated instructions of over 200 stitches. There is a photo index to quickly identify and locate a stitch you'd like to learn.