---
title: I Can Make Toys
taxonomy:
	author: [Emily Reid]
	pubdate: 2015
	isbn: 1477756450
	subjects: []
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: The Rosen Publishing Group Inc
pagecount: 32
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Can-Make-Toys-Makerspace-Projects/dp/1477756450/ref=sr_1_1?keywords=I+can+make+toys+Reid&qid=1575300987&sr=8-1
worldcat: https://www.worldcat.org/title/i-can-make-toys/oclc/922305640&referer=brief_results
google: https://play.google.com/store/books/details?id=FoVhDwAAQBAJ
---
This book is full of simple and fun crafts using your recyclables and other household materials to make toys.  Projects you will find include a sock puppet a kite, and a board game.  Each project includes a materials list and colorful instructions, as well as how to use the toy once it's finished.