---
title: Better Living Through Origami: 20 Creative Paper Projects for a Beautiful Home
taxonomy:
	author: [Nellianna van den Baard, Kenneth Veenenbos]
	pubdate: 2018
	isbn: 1446376680
	subjects: [Paper Crafts]
	audience: [General]
	expertise: [Beginner, Intermediate, Advanced]
	tag: [lesson plans]
publisher: David & Charles
pagecount: 357
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Better-Living-Through-Origami-Beautiful/dp/1446307123/ref=sr_1_1?keywords=Better+living+through+origami+%3A+20+creative+paper+projects+for+a+beautiful+home&qid=1572463464&sr=8-1
worldcat: https://www.worldcat.org/title/better-living-through-origami-20-creative-paper-projects-for-a-beautiful-home/oclc/1055266998&referer=brief_results
google: https://play.google.com/store/books/details?id=smnIDwAAQBAJ
---
If you have been looking for a way to breathe creativity into your home decor, here is your answer.  It boasts 20 paper projects integrating elements of origami and general crafting, ranging in difficulty and complexity, easy to follow diagrams, instructions, and photographs.