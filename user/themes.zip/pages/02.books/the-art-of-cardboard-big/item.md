---
title: The Art of Cardboard: Big Ideas for Creativity, Collaboration, Storytelling, and Reuse
taxonomy:
	author: [Lori Zimmer]
	pubdate: 2015
	isbn: 1631590278
	subjects: [Paper Crafts]
	audience: [K-12, College/University, General]
	expertise: [Beginner, Intermediate]
	tag: [lesson plans]
publisher: Rockport Publishers
pagecount: 160
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Art-Cardboard-Creativity-Collaboration-Storytelling/dp/1631590278/ref=pd_sim_14_11?_encoding=UTF8&pd_rd_i=1631590278&pd_rd_r=dfeda8d0-f2ca-11e8-bd66-f7675945ae46&pd_rd_w=1JeJE&pd_rd_wg=MR1X3&pf_rd_i=desktop-dp-sims&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=18bb0b78-4200-49b9-ac91-f141d61a1780&pf_rd_r=23AY9252X85P0YXCW6PG&pf_rd_s=desktop-dp-sims&pf_rd_t=40701&psc=1&refRID=23AY9252X85P0YXCW6PG
worldcat: nil
google: https://play.google.com/store/books/details?id=RP76CwAAQBAJ
---
Discusses how artists have used cardboard to do complex paper crafts while also showing introductory crafts that new users can master. Nice pairing of projects and applications