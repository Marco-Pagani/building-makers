---
title: Starting a Makerspace
taxonomy:
	author: [Pam Williams]
	pubdate: 2017
	isbn: 1634722582
	subjects: [Makerspaces - Operating]
	audience: [K-12, Libraries]
	expertise: [Beginner]
publisher: Cherry Lake
pagecount: 24
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Starting-Makerspace-Century-Innovation-Library/dp/1634723244/ref=sr_1_1?keywords=Starting+a+makerspace&qid=1572883194&sr=8-1
worldcat: https://www.worldcat.org/title/starting-a-makerspace/oclc/967683126&referer=brief_results
google: https://play.google.com/store/books/details?id=CPNKDQAAQBAJ
---
This childrens book covers all the questions your junior makers may be asking: What is a maker?  What is a makerspace? How does a makerspace work?  Including pictures and large print, this book serves to inspire the next generation of makers.