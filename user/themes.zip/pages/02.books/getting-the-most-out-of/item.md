---
title: Getting the Most Out of Makerspaces to Create with 3-D Printers
taxonomy:
	author: [Nicki Peter Petrikowski]
	pubdate: 2014
	isbn: 1477777768
	subjects: [3D Printing]
	audience: [Libraries]
	expertise: [Beginner]
publisher: The Rosen Publishing Group Inc
pagecount: 64
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Getting-Most-Makerspaces-Create-Printers/dp/1477786023/ref=sr_1_1?keywords=Getting+the+most+out+of+makerspaces+to+create+with+3-D+printers&qid=1569857195&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/getting-the-most-out-of-makerspaces-to-create-with-3-d-printers/oclc/884552729&referer=brief_results
google: https://play.google.com/store/books/details?id=pca2BQAAQBAJ
---
This is a short and easy to read crash course in 3D Printing that covers the basics of 3D printing and how to incorporate 3D printing into your makerspace.