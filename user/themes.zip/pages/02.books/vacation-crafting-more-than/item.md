---
title: Vacation Crafting: More Than 150 Fun Projects for Boys and Girls to Make
taxonomy:
	author: [Suzanne McNeill]
	pubdate: 2018
	isbn: 1641240172
	subjects: []
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
cover: http://books.google.com/books/content?id=jG25tAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
amazon: nil
worldcat: nil
google: https://books.google.com/books/about/Vacation_Crafting.html?hl=&id=jG25tAEACAAJ
---
Inspired by the classic crafts that you made in summer camp, this big book provides more than 150 child-friendly craft ideas for both girls and boys. Kids will learn to make friendship bracelets, woven potholders, pony bead animals, plastic lanyards, and much more. Using inexpensive, readily available craft supplies and simple enough to take along to the mountains or beach, it's the perfect solution for any family vacation.