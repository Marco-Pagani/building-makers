---
title: 63 Ready-to-Use Maker Projects
taxonomy:
	author: [Ellyssa Kroski]
	pubdate: 2017
	isbn: 0838916627
	subjects: [3D Modeling, Sewing, Paper Crafts, Soldering, Laser Cutting, Robotics, Photography & Video]
	audience: [Libraries, General]
	expertise: [Beginner, Intermediate]
	tag: [lesson plans]
publisher: American Library Association
pagecount: 368
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/63-Ready-Use-Maker-Projects/dp/0838915914/ref=sr_1_1?keywords=63+ready-to-use+maker+projects&qid=1575490363&sr=8-1
worldcat: https://www.worldcat.org/title/63-ready-to-use-maker-projects/oclc/1075758989&referer=brief_results
google: https://play.google.com/store/books/details?id=G6PUDwAAQBAJ
---
This expansive book includes projects from makers instructing a variety of mediums (paper, programming, wearables, 3D printing and more.  This book is a perfect catalogue of maker projects to utilize in your makerspace, whether you are running a program pr just looking for ways to build your own skills.