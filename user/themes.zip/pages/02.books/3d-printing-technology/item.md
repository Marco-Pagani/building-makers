---
title: 3D Printing: Technology, Applications, and Selection
taxonomy:
	author: [Rafiq Noorani]
	pubdate: 2017
	isbn: 1315155494
	subjects: [3D Printing]
	audience: [General]
	expertise: [Intermediate]
publisher: CRC Press Taylor & Francis Group
pagecount: 0
thumb: nil
cover: nil
amazon: https://www.amazon.com/3D-Printing-Technology-Applications-Selection/dp/1498783759/ref=sr_1_2?keywords=3D+printing+%3A+technology%2C+applications%2C+and+selection&qid=1569590604&s=gateway&sr=8-2
worldcat: https://www.worldcat.org/title/3d-printing-technology-applications-and-selection/oclc/1021403874&referer=brief_results
google: https://play.google.com/store/books/details?id=Ne23tAEACAAJ
---
3D printing : technology, applications, and selection covers how 3D printers are made, how they work, and what they can be used for.  This is a great book for anyone who wants to learn more about 3D printing as a tool.