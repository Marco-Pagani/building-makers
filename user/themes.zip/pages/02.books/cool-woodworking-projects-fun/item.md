---
title: Cool Woodworking Projects: Fun & Creative Workshop Activities
taxonomy:
	author: [Rebecca Felix]
	pubdate: 2017
	isbn: 1680775502
	subjects: [Hand Tools]
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: ABDO
pagecount: 32
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Cool-Woodworking-Projects-Activities-Industrial/dp/1680781308/ref=sr_1_1?keywords=Cool+woodworking+projects+felix&qid=1575758811&sr=8-1
worldcat: https://www.worldcat.org/title/cool-woodworking-projects/oclc/1000592007&referer=brief_results
google: https://play.google.com/store/books/details?id=QBzPDAAAQBAJ
---
This book is designed for teaching junior makers about wood working, using simple language and colorful images.  It includes an introduction to woodworking and 5 projects to build your new skills.