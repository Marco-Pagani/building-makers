---
title: Soldering
taxonomy:
	author: [David Erik Nelson, John Willis]
	pubdate: 2018
	isbn: 1510520279
	subjects: [Soldering]
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Smartbook Media Incorporated
pagecount: 32
thumb: nil
cover: nil
amazon: https://www.amazon.com/Soldering-Century-Skills-Innovation-Library/dp/1631377949/ref=sr_1_1?keywords=Soldering+Nelson&qid=1575759078&sr=8-1
worldcat: https://www.worldcat.org/title/soldering/oclc/1090415812&referer=brief_results
google: https://play.google.com/store/books/details?id=OXupwwEACAAJ
---
This book is a great introduction for a junior maker curious about soldering.  It includes chapters about what soldering is, what you use to solder, techniques used in soldering, and finishes with a project making an LED flashlight.