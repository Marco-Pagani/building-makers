---
title: Paper Crafts
taxonomy:
	author: [Annalees Lim]
	pubdate: 2013
	isbn: 1482402122
	subjects: [Paper Crafts]
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: The Rosen Publishing Group
pagecount: 34
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Paper-Crafts-Craft-Attack-Annalees/dp/1482402130/ref=sr_1_2?keywords=Paper+crafts+by+annalees+lim&qid=1570113460&s=gateway&sr=8-2
worldcat: https://www.worldcat.org/title/paper-crafts/oclc/849822431&referer=brief_results
google: https://play.google.com/store/books/details?id=Wa7nAgAAQBAJ
---
The book provides detailed illustrated instructions on 13 different types of paper crafts projects. It gives information on the toolkit or materials required to accomplish each task and a step-by-step guide for each project. It includes projects like making colorful stationary and pop-up paintings and other assorted decorations.