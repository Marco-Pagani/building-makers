---
title: Wood Carving
taxonomy:
	author: [Boy Scouts of America]
	pubdate: 1994
	isbn: 0839533098
	subjects: [Hand Tools]
	audience: []
	expertise: []
publisher: Boy Scouts of America
pagecount: 60
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: nil
worldcat: nil
google: https://play.google.com/store/books/details?id=d4WyvMFL6TcC
---
Outlines requirements for pursuing a merit badge in wood carving.