---
title: Internet of Things (IoT): Technologies, Applications, Challenges and Solutions
taxonomy:
	author: [B. K. Tripathy, J. Anuradha]
	pubdate: 2017
	isbn: 1138035009
	subjects: [Wearables, Internet of Things]
	audience: [College/University, General]
	expertise: [Intermediate, Advanced]
publisher: CRC Press
pagecount: 334
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Internet-Things-IoT-Technologies-Applications/dp/1138035009/ref=sr_1_1?ie=UTF8&qid=1543368706&sr=8-1&keywords=internet+of+things+technologies+applications+challenges+and+solutions
worldcat: nil
google: https://play.google.com/store/books/details?id=fQuKAQAACAAJ
---
The text is more of a collection about Wearables and the Internet of Things rather than an instructional text. The book covers a diverse range of technologies and the social implications.