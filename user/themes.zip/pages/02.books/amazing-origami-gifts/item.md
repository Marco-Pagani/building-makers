---
title: Amazing Origami Gifts
taxonomy:
	author: [Rob Ives]
	pubdate: 2019
	isbn: 1541542800
	subjects: []
	audience: []
	expertise: []
publisher: Hungry Tomato
pagecount: 0
thumb: nil
cover: nil
amazon: https://www.amazon.com/Amazing-Origami-Gifts-Rob-Ives/dp/1541501241/ref=sr_1_1?crid=QNMU4RZO6NRX&keywords=amazing+origami+gifts+rob+ives&qid=1570113542&s=gateway&sprefix=Amazing+origami+gifts+r%2Caps%2C168&sr=8-1
worldcat: https://www.worldcat.org/title/amazing-origami-gifts/oclc/1042077223&referer=brief_results
google: https://play.google.com/store/books/details?id=XvZGuQEACAAJ
---
"Create handmade origami gifts for your friends and family, such as a pencil case, gift boxes, and a paper flower bouquet. Step-by-step instructions and photographs guide readers through projects of varied difficulty to increase visual-spatial reasoning skills --