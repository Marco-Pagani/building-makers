---
title: Macrame for Home Decor: 40 Stunning Projects for Stylish Decorating
taxonomy:
	author: [Samantha Grenier]
	pubdate: 2018
	isbn: 1565239512
	subjects: [Fiber Arts]
	audience: [General]
	expertise: [Advanced]
	tag: [lesson plans]
publisher: Fox Chapel Publishing Company Incorporated
pagecount: 160
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Macrame-Home-Decor-Step-Step/dp/1565239512/ref=sr_1_1?keywords=Macram%C3%A9+for+home+decor+%3A+40+stunning+projects+for+stylish+decorating&qid=1570112480&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/macrame-for-home-decor-40-stunning-projects-for-stylish-decorating/oclc/1036786995&referer=brief_results
google: https://play.google.com/store/books/details?id=bkFmtAEACAAJ
---
The book starts with basic lessons on macrame and the basic toolkit and extends to 40 projects of varying complexity. Each project has detailed and illustrated step-by-step instructions. Each project is both decorative and useful for household and domestic purposes. Projects include many different types of home decor, plant hangers, wall hangings and mats