---
title: 3D Modeling
taxonomy:
	author: [Theo Zizka]
	pubdate: 2014
	isbn: 1631378120
	subjects: [3D Modeling]
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Cherry Lake
pagecount: 32
thumb: small.jpeg
cover: extraLarge.jpeg
amazon: https://www.amazon.com/Modeling-Century-Skills-Innovation-Library/dp/1631377922/ref=sr_1_1?keywords=3D+Modeling+%3A+21st+Century+Skills+Innovation+Library&qid=1575300157&sr=8-1
worldcat: https://www.worldcat.org/title/3d-modeling-21st-century-skills-innovation-library/oclc/963796740&referer=brief_results
google: https://play.google.com/store/books/details?id=o1-8BgAAQBAJ
---
This book explores the basics of 3D modeling using the free SketchUp software.  It also suggests ways to  further develop your 3D modeling skills once you finish the book.