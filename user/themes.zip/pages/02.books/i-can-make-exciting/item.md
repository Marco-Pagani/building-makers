---
title: I Can Make Exciting Electronics
taxonomy:
	author: [Kristina A. Holzweiss, Amy Barth]
	pubdate: 2017
	isbn: 0531234118
	subjects: []
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: Scholastic Incorporated
pagecount: 32
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Exciting-Electronics-Rookie-Makerspace-Projects/dp/0531238806/ref=sr_1_1?keywords=I+can+make+exciting+electronics&qid=1574640340&sr=8-1
worldcat: https://www.worldcat.org/title/i-can-make-exciting-electronics/oclc/981948537&referer=brief_results
google: https://play.google.com/store/books/details?id=CmtOAQAACAAJ
---
This is the perfect book to introduce your youngsters to electronics.  It contains three simple and fun projects to teach about electric currents, lights and the types of circuits.  It wraps up with some interesting history about electricity.