---
title: 25 Projects for Art Explorers
taxonomy:
	author: [Christine Kirker]
	pubdate: 2018
	isbn: 0838917399
	subjects: []
	audience: [K-12]
	expertise: [Beginner]
	tag: [lesson plans]
publisher: American Library Association
pagecount: 64
thumb: thumbnail.jpeg
cover: thumbnail.jpeg
amazon: https://www.amazon.com/Projects-Art-Explorers-Christine-Kirker/dp/0838917399/ref=sr_1_1?keywords=25+projects+for+art+explorers&qid=1570114504&s=gateway&sr=8-1
worldcat: https://www.worldcat.org/title/25-projects-for-art-explorers/oclc/1040677777&referer=brief_results
google: https://play.google.com/store/books/details?id=W8tCuQEACAAJ
---
The book provides instructions on different art projects using a variety of materials and techniques. Each project is presented through an example of a picture book. Children see how it is used in the text. It is then followed by a list of materials required and instructions. The illustrations are imaginative and allow children to think of art as an imaginative and applied process.