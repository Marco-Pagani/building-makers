---
title: Arduino workshop: a hands-on introduction with 65 projects
taxonomy:
	author: John Boxall
	pubdate: 2013
	audience: General,College/University,Libraries
	expertise: Beginner,Intermediate
---
## Arduino workshop: a hands-on introduction with 65 projects
### By John Boxall

**Publication Date:** 2013

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** General,College/University,Libraries

**ISBN:** 978-1593274481

[Amazon Link](https://www.amazon.com/Arduino-Workshop-Hands-Introduction-Projects/dp/1593274483/ref=sr_1_1?ie=UTF8&qid=1541631535&sr=8-1&keywords=arduino+workshop)