---
title: Python for Kids : a playful introduction to programming
taxonomy:
	author: Jason R.,Briggs
	pubdate: 2012
	audience: 
	expertise: 
---
## Python for Kids : a playful introduction to programming
### By Jason R.,Briggs

**Publication Date:** 2012

**ISBN:** 1-59327-407-6