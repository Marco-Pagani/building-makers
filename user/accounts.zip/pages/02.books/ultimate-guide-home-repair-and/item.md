---
title: Ultimate guide home repair and improvement
taxonomy:
	author: ; Creative Homeowner Press.,Charles T.,Byers
	pubdate: 2017
	audience: General
	expertise: Advanced
---
## Ultimate guide home repair and improvement
### By ; Creative Homeowner Press.,Charles T.,Byers
The book provides detailed instruction on mending common household damages. It provides illustrated guidance on household repairs on an exhaustive list of damages and construction works. It also includes a comprehensive list of materials required for completing the tasks. 

**Publication Date:** 2017

**Expertise Level:** Advanced

**Intended Audience:** General

**ISBN:** 978-1-58011-783-8 1-58011-783-X

[Amazon Link](https://www.amazon.com/Ultimate-Guide-Repair-Improvement-Updated/dp/158011783X/ref=sr_1_3?keywords=Ultimate+guide+home+repair+and+improvement&qid=1570112105&s=gateway&sr=8-3)

[Worldcat Link](https://www.worldcat.org/title/ultimate-guide-home-repair-and-improvement/oclc/959029423&referer=brief_results)