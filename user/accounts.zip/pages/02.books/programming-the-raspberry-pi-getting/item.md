---
title: Programming the Raspberry Pi : getting started with Python
taxonomy:
	author: Simon,Monk
	pubdate: 2016
	audience: 
	expertise: 
---
## Programming the Raspberry Pi : getting started with Python
### By Simon,Monk

**Publication Date:** 2016

**ISBN:** 1-259-58740-1