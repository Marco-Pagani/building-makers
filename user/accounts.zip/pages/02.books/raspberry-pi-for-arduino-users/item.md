---
title: Raspberry Pi for Arduino users : building IoT and network applications and devices
taxonomy:
	author: James R.,Strickland
	pubdate: 2018
	audience: General
	expertise: Intermediate,Advanced
---
## Raspberry Pi for Arduino users : building IoT and network applications and devices
### By James R.,Strickland
This book builds off of your Arduino skills to show you how to use Raspberry Pi's to create even cooler electronics.  You will learn some C++ coding, connecting your applications to the internet, and more.

**Publication Date:** 2018

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** General

**ISBN:** 1-4842-3413-8

[Amazon Link](https://www.amazon.com/Raspberry-Pi-Arduino-Users-Applications/dp/1484234138/ref=sr_1_1?keywords=Raspberry+Pi+for+Arduino+users+%3A+building+IoT+and+network+applications+and+devices&qid=1574352197&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/raspberry-pi-for-arduino-users-building-iot-and-network-applications-and-devices/oclc/1050941736&referer=brief_results)