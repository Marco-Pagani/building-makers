---
title: Knit, Hook, and Spin: A Kid's Activity Guide to Fiber Arts and Crafts
taxonomy:
	author: Laurie,Carlson
	pubdate: 2016
	audience: 
	expertise: 
---
## Knit, Hook, and Spin: A Kid's Activity Guide to Fiber Arts and Crafts
### By Laurie,Carlson

**Publication Date:** 2016

**ISBN:** 978-1-61373-403-2