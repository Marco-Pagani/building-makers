---
title: Paper crafts
taxonomy:
	author: Annalees.,Lim
	pubdate: 2014
	audience: K-12
	expertise: Beginner
---
## Paper crafts
### By Annalees.,Lim
The book provides detailed illustrated instructions on 13 different types of paper crafts projects. It gives information on the toolkit or materials required to accomplish each task and a step-by-step guide for each project. It includes projects like making colorful stationary and pop-up paintings and other assorted decorations.

**Publication Date:** 2014

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-4824-0211-7 1-4824-0211-4 978-1-4824-0213-1 1-4824-0213-0 978-1-4824-0214-8 1-4824-0214-9

[Amazon Link](https://www.amazon.com/Paper-Crafts-Craft-Attack-Annalees/dp/1482402130/ref=sr_1_2?keywords=Paper+crafts+by+annalees+lim&qid=1570113460&s=gateway&sr=8-2)

[Worldcat Link](https://www.worldcat.org/title/paper-crafts/oclc/849822431&referer=brief_results)