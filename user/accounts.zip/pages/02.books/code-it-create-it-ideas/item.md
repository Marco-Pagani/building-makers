---
title: Code it! Create it! : ideas + inspiration for coding
taxonomy:
	author: Brenna,Sarah; Vaughan,Hutt
	pubdate: 2017
	audience: 
	expertise: 
---
## Code it! Create it! : ideas + inspiration for coding
### By Brenna,Sarah; Vaughan,Hutt

**Publication Date:** 2017

**ISBN:** 978-0-399-54255-8