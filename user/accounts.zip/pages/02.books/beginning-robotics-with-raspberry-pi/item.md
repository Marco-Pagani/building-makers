---
title: Beginning robotics with Raspberry Pi and Arduino : using Python and OpenCV
taxonomy:
	author: Jeff,Cicolani
	pubdate: 2018
	audience: General
	expertise: Beginner
---
## Beginning robotics with Raspberry Pi and Arduino : using Python and OpenCV
### By Jeff,Cicolani
Beginning robotics with Raspberry Pi and Arduino : using Python and OpenCV is intended for beginners to robotics who would like to start their robotics journey.  It covers the basics of robotics, assembly, soldering.  It also introduces you to two coding languages. 

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** General

**ISBN:** 10.1007/978-1-4842-3462-4 doi

[Amazon Link](https://www.amazon.com/Beginning-Robotics-Raspberry-Pi-Arduino/dp/1484234618/ref=sr_1_1?keywords=Beginning+robotics+with+Raspberry+Pi+and+Arduino+%3A+using+Python+and+OpenCV&qid=1570651362&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/beginning-robotics-with-raspberry-pi-and-arduino-using-python-and-opencv/oclc/1016924863&referer=brief_results)