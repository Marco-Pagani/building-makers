---
title: Carpentry
taxonomy:
	author: Cool Springs Press
	pubdate: 2013
	audience: General
	expertise: Beginner,Intermediate,Advanced
---
## Carpentry
### By Cool Springs Press
This book offers expansive instructions on carpentry for the home.  It covers necessary tools and materials and instructions on crafting your home's skeleton.   

**Publication Date:** 2013

**Expertise Level:** Beginner,Intermediate,Advanced

**Intended Audience:** General

**ISBN:** 9.78E+12

[Amazon Link](https://www.amazon.com/HomeSkills-Carpentry-Introduction-Drilling-Shaping/dp/1591865794/ref=sr_1_1?keywords=Carpentry%3A+An+Introduction+To+Sawing%2C+Drilling%2C+Shaping+%26+Joining+Wood&qid=1575491667&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/homeskills-carpentry-an-introduction-to-sawing-drilling-shaping-joining-wood/oclc/854853870&referer=brief_results)