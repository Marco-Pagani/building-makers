---
title: Wood carving
taxonomy:
	author: Boy Scouts of America
	pubdate: 2016
	audience: 
	expertise: 
---
## Wood carving
### By Boy Scouts of America

**Publication Date:** 2016

**ISBN:** 978-0-8395-3309-2 0-8395-3309-8