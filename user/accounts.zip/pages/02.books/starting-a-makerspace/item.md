---
title: Starting a makerspace
taxonomy:
	author: Pamela,Williams
	pubdate: 2017
	audience: K-12,Libraries
	expertise: Beginner
---
## Starting a makerspace
### By Pamela,Williams
This childrens book covers all the questions your junior makers may be asking: What is a maker?  What is a makerspace? How does a makerspace work?  Including pictures and large print, this book serves to inspire the next generation of makers. 

**Publication Date:** 2017

**Expertise Level:** Beginner

**Intended Audience:** K-12,Libraries

**ISBN:** 978-1-63472-192-9 1-63472-192-6 978-1-63472-324-4 1-63472-324-4

[Amazon Link](https://www.amazon.com/Starting-Makerspace-Century-Innovation-Library/dp/1634723244/ref=sr_1_1?keywords=Starting+a+makerspace&qid=1572883194&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/starting-a-makerspace/oclc/967683126&referer=brief_results)