---
title: Internet of things
taxonomy:
	author: Lisa J.,Amstutz
	pubdate: 2020
	audience: 
	expertise: 
---
## Internet of things
### By Lisa J.,Amstutz

**Publication Date:** 2020

**ISBN:** 978-1-64493-004-5 1-64493-004-8 978-1-64185-918-9 1-64185-918-0