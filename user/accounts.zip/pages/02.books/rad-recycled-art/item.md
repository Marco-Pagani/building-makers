---
title: Rad recycled art
taxonomy:
	author: Emily,Kington
	pubdate: 2019
	audience: K-12
	expertise: Beginner
---
## Rad recycled art
### By Emily,Kington
The book contains craft projects made from recycled easily available household material. Each project contains detailed instructions and a list of materials required. The goal of every project is to develop something that could be used in everyday life and also looks colorful and quirky.

**Publication Date:** 2019

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-912108-50-3 1-912108-50-X

[Amazon Link](https://www.amazon.com/Rad-Recycled-Art-Wild-Projects-ebook/dp/B07JK6HQMQ/ref=sr_1_1?keywords=Rad+recycled+art&qid=1570114220&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/rad-recycled-art/oclc/1099594168&referer=brief_results)