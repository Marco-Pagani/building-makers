---
title: Organizing a makerfest
taxonomy:
	author: Kristin,Fontichiaro
	pubdate: 2017
	audience: K-12
	expertise: Intermediate
---
## Organizing a makerfest
### By Kristin,Fontichiaro
This book is meant to inform children about what Makerfests are and how they can help organize and run a Makerfest with the help of trusted adults.  It includes setting up, finding volunteers to help run maker stations and more.

**Publication Date:** 2017

**Expertise Level:** Intermediate

**Intended Audience:** K-12

**ISBN:** 978-1-63472-190-5 1-63472-190-X 978-1-63472-322-0 1-63472-322-8

[Amazon Link](https://www.amazon.com/Organizing-Makerfest-Makers-as-Innovators/dp/1634723228)

[Worldcat Link](https://www.worldcat.org/title/organizing-a-makerfest/oclc/967683438&referer=brief_results)