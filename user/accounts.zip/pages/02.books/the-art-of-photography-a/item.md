---
title: The Art of Photography : A Personal Approach to Artistic Expression, 2nd Edition
taxonomy:
	author: Bruce,Barnbaum
	pubdate: 2017
	audience: 
	expertise: 
---
## The Art of Photography : A Personal Approach to Artistic Expression, 2nd Edition
### By Bruce,Barnbaum

**Publication Date:** 2017

**ISBN:** 1-68198-210-2