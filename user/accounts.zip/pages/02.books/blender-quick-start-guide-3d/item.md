---
title: Blender Quick Start Guide: 3D Modeling, Animation, and Render with Eevee in Blender 2.8
taxonomy:
	author: Allan,Brito
	pubdate: 2018
	audience: 
	expertise: 
---
## Blender Quick Start Guide: 3D Modeling, Animation, and Render with Eevee in Blender 2.8
### By Allan,Brito

**Publication Date:** 2018

**ISBN:** 978-1-78961-293-6