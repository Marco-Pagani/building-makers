---
title: Development of creative spaces in academic libraries : a decision maker's guide
taxonomy:
	author: Katy Kavanagh,Webb
	pubdate: 2018
	audience: 
	expertise: 
---
## Development of creative spaces in academic libraries : a decision maker's guide
### By Katy Kavanagh,Webb

**Publication Date:** 2018

**ISBN:** 0-08-102266-2 978-0-08-102266-5

[Amazon Link](https://www.amazon.com/Development-Creative-Spaces-Academic-Libraries/dp/0081022662/ref=sr_1_1?keywords=Development+of+creative+spaces+in+academic+libraries+%3A+a+decision+maker%27s+guide&qid=1570113871&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/development-of-creative-spaces-in-academic-libraries-a-decision-makers-guide/oclc/1079360576&referer=brief_results)