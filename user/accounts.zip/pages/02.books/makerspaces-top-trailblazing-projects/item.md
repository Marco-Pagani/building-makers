---
title: Makerspaces : top trailblazing projects
taxonomy:
	author: Caitlin A.,Bagley
	pubdate: 2014
	audience: College/University,Libraries
	expertise: Advanced
---
## Makerspaces : top trailblazing projects
### By Caitlin A.,Bagley
The book provides information on Makerspace and its different uses and applications. It then provides a detailed description and analysis of some of the most successful makerspace projects at both academic and public libraries. It provides useful information which readers can apply to their own institutions.

**Publication Date:** 2014

**Expertise Level:** Advanced

**Intended Audience:** College/University,Libraries

**ISBN:** 978-1-55570-990-7 (paper), 978-1-55570-991-4 (PDF),  978-1-55570-992-1 (ePub),  978-1-55570-993-8 (Kindle)

[Amazon Link](https://www.amazon.com/Makerspaces-Trailblazing-Projects-LITA-Guide-ebook/dp/B00JLQTIHK/ref=sr_1_1?keywords=Makerspaces+%3A+top+trailblazing+projects&qid=1569877251&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/makerspaces-top-trailblazing-projects/oclc/937883152&referer=brief_results)