---
title: Holiday Paper Crafts: Create Over 25 Beautifully Designed Holiday Craft Decorations for Your Home
taxonomy:
	author: Larimer Craft &,Design
	pubdate: 2017
	audience: General
	expertise: Advanced
---
## Holiday Paper Crafts: Create Over 25 Beautifully Designed Holiday Craft Decorations for Your Home
### By Larimer Craft &,Design
This festive book is full of crafts for decorations sure to get you in the holiday spirit.  You will find intractions to make  paper lanterns, paper ornaments, a paper holiday village, and more.  The skills developed in this book include paper cutting, kirigami and origami.

**Publication Date:** 2017

**Expertise Level:** Advanced

**Intended Audience:** General

**ISBN:** 978-1-68188-260-4

[Amazon Link](https://www.amazon.com/Holiday-Paper-Crafts-Beautifully-Decorations/dp/1681882604/ref=sr_1_1?keywords=Holiday+Paper+Crafts%3A+Create+Over+25+Beautifully+Designed+Holiday+Craft+Decorations+for+Your+Home&qid=1575301946&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/holiday-paper-crafts-25-beautifully-designed-crafts/oclc/975087270&referer=brief_results)