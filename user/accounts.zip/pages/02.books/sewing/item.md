---
title: Sewing
taxonomy:
	author: Stephanie,Turnbull
	pubdate: 2016
	audience: K-12
	expertise: Beginner
---
## Sewing
### By Stephanie,Turnbull
This easy-to-read book features colorful illustrations and clear instructions teaching basic sewing. It also includes 7 projects perfect to complete in a classroom or at home.

**Publication Date:** 2016

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-62588-375-9 1-62588-375-7

[Amazon Link](https://www.amazon.com/Sewing-Try-This-Stephanie-Turnbull/dp/1625883757/ref=sr_1_1?keywords=sewing+turnbull&qid=1571174703&sr=8-1)

[Worldcat Link](worldcat.org/title/sewing/oclc/910531136&referer=brief_results)