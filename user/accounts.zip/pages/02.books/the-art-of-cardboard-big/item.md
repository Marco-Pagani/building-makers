---
title: The Art of Cardboard: Big Ideas for Creativity, Collaboration, Storytelling, and Reuse
taxonomy:
	author: Lori Zimmer
	pubdate: 2015
	audience: K-12,College/University,General
	expertise: Beginner,Intermediate
---
## The Art of Cardboard: Big Ideas for Creativity, Collaboration, Storytelling, and Reuse
### By Lori Zimmer
Discusses how artists have used cardboard to do complex paper crafts while also showing introductory crafts that new users can master. Nice pairing of projects and applications

**Publication Date:** 2015

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** K-12,College/University,General

**ISBN:** 978-1631590276

[Amazon Link](https://www.amazon.com/Art-Cardboard-Creativity-Collaboration-Storytelling/dp/1631590278/ref=pd_sim_14_11?_encoding=UTF8&pd_rd_i=1631590278&pd_rd_r=dfeda8d0-f2ca-11e8-bd66-f7675945ae46&pd_rd_w=1JeJE&pd_rd_wg=MR1X3&pf_rd_i=desktop-dp-sims&pf_rd_m=ATVPDKIKX0DER&pf_rd_p=18bb0b78-4200-49b9-ac91-f141d61a1780&pf_rd_r=23AY9252X85P0YXCW6PG&pf_rd_s=desktop-dp-sims&pf_rd_t=40701&psc=1&refRID=23AY9252X85P0YXCW6PG)