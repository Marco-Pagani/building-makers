---
title: 3D CAD with Autodesk 123D : designing for 3D printing, laser cutting, and personal fabrication
taxonomy:
	author: Emily,; Gertz,Jesse Harrington,Au
	pubdate: 2016
	audience: 
	expertise: 
---
## 3D CAD with Autodesk 123D : designing for 3D printing, laser cutting, and personal fabrication
### By Emily,; Gertz,Jesse Harrington,Au

**Publication Date:** 2016

**ISBN:** 978-1-4493-4301-9 1-4493-4301-5