---
title: Wearable Computers and Augmented Reality
taxonomy:
	author: Woodrow Barfield
	pubdate: 2016
	audience: General,College/University
	expertise: Intermediate,Advanced
---
## Wearable Computers and Augmented Reality
### By Woodrow Barfield
The text details more of the applications and history of wearables and augmented reality, as well as a few other haptic and visual displays. Fundamentals of Wearable Computers and Augmented Reality goes beyond smart clothing to explore user interface design issues specific to wearable tech and areas in which it can be applied.

**Publication Date:** 2016

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** General,College/University

**ISBN:** 978-1138749313

[Amazon Link](https://www.amazon.com/Fundamentals-Wearable-Computers-Augmented-Reality-ebook/dp/B011NH3DB6/ref=sr_1_1?ie=UTF8&qid=1543370188&sr=8-1&keywords=wearable+computers+and+augmented+reality)