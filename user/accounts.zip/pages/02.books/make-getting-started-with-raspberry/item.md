---
title: Make: Getting Started with Raspberry Pi
taxonomy:
	author: Matt Richardson,Shawn P. Wallace
	pubdate: 2016
	audience: 
	expertise: 
---
## Make: Getting Started with Raspberry Pi
### By Matt Richardson,Shawn P. Wallace
3rd edition. 

**Publication Date:** 2016

**ISBN:** 9.78E+12

[Worldcat Link](http://www.worldcat.org/oclc/967651253)