---
title: Woodworking with hand tools : tools, techniques & projects
taxonomy:
	author: Taunton Press
	pubdate: 2018
	audience: 
	expertise: 
---
## Woodworking with hand tools : tools, techniques & projects
### By Taunton Press

**Publication Date:** 2018

**ISBN:** 978-1-63186-939-6 1-63186-939-6