---
title: Getting the most out of makerspaces to create with 3-D printers
taxonomy:
	author: """Petrikowski, Nicki Peter"""
	pubdate: 2015
	audience: Libraries
	expertise: Beginner
---
## Getting the most out of makerspaces to create with 3-D printers
### By """Petrikowski, Nicki Peter"""
This is a short and easy to read crash course in 3D Printing that covers the basics of 3D printing and how to incorporate 3D printing into your makerspace.

**Publication Date:** 2015

**Expertise Level:** Beginner

**Intended Audience:** Libraries

**ISBN:** 978-1477778135

[Amazon Link](https://www.amazon.com/Getting-Most-Makerspaces-Create-Printers/dp/1477786023/ref=sr_1_1?keywords=Getting+the+most+out+of+makerspaces+to+create+with+3-D+printers&qid=1569857195&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/getting-the-most-out-of-makerspaces-to-create-with-3-d-printers/oclc/884552729&referer=brief_results)