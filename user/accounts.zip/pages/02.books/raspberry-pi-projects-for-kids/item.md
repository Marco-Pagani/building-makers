---
title: Raspberry Pi Projects for Kids.
taxonomy:
	author: Daniel (Computer science researcher),Bates
	pubdate: 2014
	audience: 
	expertise: 
---
## Raspberry Pi Projects for Kids.
### By Daniel (Computer science researcher),Bates

**Publication Date:** 2014

**ISBN:** 1-306-53840-8