---
title: 63 ready-to-use maker projects
taxonomy:
	author: Ellyssa,Kroski
	pubdate: 2018
	audience: Libraries,General
	expertise: Beginner,Intermediate
---
## 63 ready-to-use maker projects
### By Ellyssa,Kroski
This expansive book includes projects from makers instructing a variety of mediums (paper, programming, wearables, 3D printing and more.  This book is a perfect catalogue of maker projects to utilize in your makerspace, whether you are running a program pr just looking for ways to build your own skills.

**Publication Date:** 2018

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** Libraries,General

**ISBN:** 0-8389-1591-4

[Amazon Link](https://www.amazon.com/63-Ready-Use-Maker-Projects/dp/0838915914/ref=sr_1_1?keywords=63+ready-to-use+maker+projects&qid=1575490363&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/63-ready-to-use-maker-projects/oclc/1075758989&referer=brief_results)