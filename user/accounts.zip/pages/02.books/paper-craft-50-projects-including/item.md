---
title: Paper Craft: 50 Projects Including Card Making, Gift Wrapping, Scrapbooking, and Beautiful Paper Flowers
taxonomy:
	author: 
	pubdate: 2015
	audience: General
	expertise: Beginner,Intermediate
---
## Paper Craft: 50 Projects Including Card Making, Gift Wrapping, Scrapbooking, and Beautiful Paper Flowers
After a brief introduction of the materials and equipment you need, this book dives right in to a variety of paper projects, including three different kinds of gift boxes, quilled earrings, twelve floral projects, and more.  Each project includes a list of necessary materials and tools as well as step by step instructions and images to make following along a breeze.

**Publication Date:** 2015

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** General

**ISBN:** 978-1-4654-4965-8

[Amazon Link](https://www.amazon.com/Paper-Craft-Including-Scrapbooking-Beautiful/dp/1465439439/ref=sr_1_1?keywords=Paper+Craft%3A+50+Projects+Including+Card+Making%2C+Gift+Wrapping%2C+Scrapbooking%2C+and+Beautiful+Paper+Flowers&qid=1573574407&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/paper-craft-50-projects-including-card-making-gift-wrapping-scrapbooking-and-beautiful-paper-flowers/oclc/945404875&referer=brief_results)