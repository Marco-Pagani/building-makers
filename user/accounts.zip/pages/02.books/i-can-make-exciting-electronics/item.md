---
title: I can make exciting electronics
taxonomy:
	author: Amy,; Barth,Kristina,Holzweiss
	pubdate: 2018
	audience: K-12
	expertise: Beginner
---
## I can make exciting electronics
### By Amy,; Barth,Kristina,Holzweiss
This is the perfect book to introduce your youngsters to electronics.  It contains three simple and fun projects to teach about electric currents, lights and the types of circuits.  It wraps up with some interesting history about electricity.

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-0-531-23411-2 0-531-23411-8 978-0-531-23880-6 0-531-23880-6

[Amazon Link](https://www.amazon.com/Exciting-Electronics-Rookie-Makerspace-Projects/dp/0531238806/ref=sr_1_1?keywords=I+can+make+exciting+electronics&qid=1574640340&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/i-can-make-exciting-electronics/oclc/981948537&referer=brief_results)