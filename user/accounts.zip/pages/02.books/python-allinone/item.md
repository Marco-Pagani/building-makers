---
title: Python all-in-one
taxonomy:
	author: Alan,John C.; Simpson,Shovic
	pubdate: 2019
	audience: General
	expertise: Beginner,Intermediate
---
## Python all-in-one
### By Alan,John C.; Simpson,Shovic
This easy-to-read book is a great introduction to the Python coding language and covers many of the skills you will need to use Python, like entering commends, sidestepping errors, and managing your python files.  It also dives into artificial intelligence and robotics, two important applications of python.

**Publication Date:** 2019

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** General

**ISBN:** 1-119-55759-3

[Amazon Link](https://www.amazon.com/Python-All-One-Dummies-Shovic/dp/1119557593/ref=sr_1_1?keywords=Python+all-in-one&qid=1575492272&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/python-all-in-one/oclc/1122746992&referer=brief_results)