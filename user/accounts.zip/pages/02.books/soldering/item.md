---
title: Soldering
taxonomy:
	author: John,; Willis,David Erik,Nelson
	pubdate: 2014
	audience: K-12
	expertise: Beginner
---
## Soldering
### By John,; Willis,David Erik,Nelson
This book is a great introduction for a junior maker curious about soldering.  It includes chapters about what soldering is, what you use to solder, techniques used in soldering, and finishes with a project making an LED flashlight.

**Publication Date:** 2014

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 9781510520271 1510520279

[Amazon Link](https://www.amazon.com/Soldering-Century-Skills-Innovation-Library/dp/1631377949/ref=sr_1_1?keywords=Soldering+Nelson&qid=1575759078&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/soldering/oclc/1090415812&referer=brief_results)