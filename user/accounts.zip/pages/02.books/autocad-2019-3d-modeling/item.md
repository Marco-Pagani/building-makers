---
title: AutoCAD 2019: 3D Modeling
taxonomy:
	author: Munir,Hamad
	pubdate: 2019
	audience: College/University,Libraries
	expertise: Intermediate
---
## AutoCAD 2019: 3D Modeling
### By Munir,Hamad
AutoCAD 2019: 3D Modeling covers everything from the basics of AutoCAD like how to view a design in a 3 dimensional plain to designing different kinds of surfaces to assigning materials to your design to animating or printing your design.

**Publication Date:** 2019

**Expertise Level:** Intermediate

**Intended Audience:** College/University,Libraries

**ISBN:** 168392178X

[Amazon Link](https://www.amazon.com/AutoCAD-2019-Modeling-Munir-Hamad-ebook/dp/B07FKQSFJ6/ref=sr_1_9?keywords=AutoCAD+2019%3A+3D+Modeling&qid=1569589687&s=gateway&sr=8-9)

[Worldcat Link](https://www.worldcat.org/title/autocad-2019-3d-modeling/oclc/1038803522&referer=brief_results)