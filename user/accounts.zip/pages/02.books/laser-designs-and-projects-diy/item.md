---
title: Laser Designs and Projects: DIY Projects in Corel Draw to cut out and decorate with a laser
taxonomy:
	author: William F Nelson Jr
	pubdate: 2018
	audience: College/University,General
	expertise: Intermediate,Advanced
---
## Laser Designs and Projects: DIY Projects in Corel Draw to cut out and decorate with a laser
### By William F Nelson Jr
Book of projects and designs - very little instruction - for more advanced users or people looking for patterns

**Publication Date:** 2018

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** College/University,General

**ISBN:** 978-0692140130

[Amazon Link](https://www.amazon.com/Laser-Designs-Projects-decorate-machine/dp/0692140131/ref=sr_1_18?s=books&ie=UTF8&qid=1543380840&sr=1-18&keywords=Laser+Cutting)