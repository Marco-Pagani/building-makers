---
title: Photoshop Elements 2018 Tips, Tricks & Shortcuts in Easy Steps
taxonomy:
	author: Nick,Vandome
	pubdate: 2018
	audience: General
	expertise: Beginner
---
## Photoshop Elements 2018 Tips, Tricks & Shortcuts in Easy Steps
### By Nick,Vandome
Designed for a beginner to photoshop, this book contains tips and tricks that would be useful to even a seasoned photoshop user.  It includes instructions and tricks regarding color editing, layers, and more.

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** General

**ISBN:** 1-84078-803-8

[Amazon Link](https://www.amazon.com/Photoshop-Elements-Tricks-Shortcuts-steps/dp/1840788038/ref=sr_1_1?keywords=Photoshop+Elements+2018+Tips%2C+Tricks+%26+Shortcuts+in+Easy+Steps&qid=1571082055&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/photoshop-elements-2018-tips-tricks-shortcuts-for-windows-and-mac/oclc/1035516524&referer=brief_results)