---
title: Quilled mandalas : 30 paper projects for creativity and relaxation
taxonomy:
	author: Alli,Bartkowski
	pubdate: 2016
	audience: 
	expertise: 
---
## Quilled mandalas : 30 paper projects for creativity and relaxation
### By Alli,Bartkowski

**Publication Date:** 2016