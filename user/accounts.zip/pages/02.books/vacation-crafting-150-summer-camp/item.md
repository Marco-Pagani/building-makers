---
title: Vacation crafting : 150+ summer camp projects for boys & girls to make
taxonomy:
	author: Suzanne,McNeill
	pubdate: 2018
	audience: K-12
	expertise: Beginner
---
## Vacation crafting : 150+ summer camp projects for boys & girls to make
### By Suzanne,McNeill

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-64124-017-8 1-64124-017-2