---
title: Electronic Projects to Build On
taxonomy:
	author: Tammy,Enz
	pubdate: 2019
	audience: General
	expertise: Beginner
---
## Electronic Projects to Build On
### By Tammy,Enz
This book is a great source of projects to begin developing skills in LED lighting, circuits, breadboards, and tilt switches.  Each subject is a multistep project designed to break up the skills to be more easily absorbed.  The pages also contain colorful pictures and graphics to help guide you through the projects.

**Publication Date:** 2019

**Expertise Level:** Beginner

**Intended Audience:** General

**ISBN:** 1474775403

[Amazon Link](https://www.amazon.com/Electronics-Projects-Build-Dabble-Lab/dp/1474775403/ref=sr_1_1?keywords=Electronic+Projects+to+Build+On+enz&qid=1574641230&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/electronics-projects-to-build-on/oclc/1084302111&referer=brief_results)