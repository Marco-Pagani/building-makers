---
title: I'm an app developer
taxonomy:
	author: Max,Wainewright
	pubdate: 2018
	audience: K-12
	expertise: Beginner
---
## I'm an app developer
### By Max,Wainewright
In this book you will learn how to make apps with the App Inventor from Google.  The unctions require an Android device or Android emulator, which can be downloaded onto a computer.  The book teaches basic coding inputs and guides you through the steps of designing 6 simple app projects like a translator and a photo painter. The book also offers advice for sharing your app with your loved ones.

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-5263-0107-9 1-5263-0107-5

[Amazon Link](https://www.amazon.com/Im-App-Developer-Programs-Generation/dp/0778735281/ref=sr_1_1?keywords=I%27m+an+app+developer&qid=1573770757&s=books&sr=1-1)

[Worldcat Link](https://www.worldcat.org/title/im-an-app-developer/oclc/1035213454&referer=brief_results)