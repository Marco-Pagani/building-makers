---
title: The essential guide to HTML5 : using games to learn HTML5 and JavaScript
taxonomy:
	author: Jeanine,Meyer
	pubdate: 2018
	audience: 
	expertise: 
---
## The essential guide to HTML5 : using games to learn HTML5 and JavaScript
### By Jeanine,Meyer

**Publication Date:** 2018

**ISBN:** 1-4842-4154-1