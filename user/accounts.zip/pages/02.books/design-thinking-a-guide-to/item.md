---
title: Design thinking : a guide to creative problem solving for everyone
taxonomy:
	author: Andy,Pressman
	pubdate: 2019
	audience: 
	expertise: 
---
## Design thinking : a guide to creative problem solving for everyone
### By Andy,Pressman

**Publication Date:** 2019

**ISBN:** 1-138-67345-5