---
title: I can make remarkable robots
taxonomy:
	author: Amy,; Barth,Kristina,Holzweiss
	pubdate: 2018
	audience: K-12
	expertise: Beginner
---
## I can make remarkable robots
### By Amy,; Barth,Kristina,Holzweiss
This fun and colorful book contains 3 projects to teach your child the basics of robotics.  Each project includes a materials list, background information, and step by step instructions and pictures to guide you and your child to the finished product.

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-0-531-23410-5 0-531-23410-X 978-0-531-23879-0 0-531-23879-2