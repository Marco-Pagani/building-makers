---
title: Arduino Microcontroller: Processing for Everyone!
taxonomy:
	author: Steven F. Barrett
	pubdate: 2012
	audience: College/University,K-12,Libraries,General
	expertise: Beginner,Intermediate
---
## Arduino Microcontroller: Processing for Everyone!
### By Steven F. Barrett
UF Library Online link

**Publication Date:** 2012

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** College/University,K-12,Libraries,General

**ISBN:** 978-1627052535

[Amazon Link](https://www.amazon.com/Arduino-Microcontroller-Processing-Everyone-Synthesis/dp/1627052534/ref=sr_1_2?s=books&ie=UTF8&qid=1541656853&sr=1-2&keywords=arduino+microcontroller)

[Worldcat Link](http://www.worldcat.org/oclc/862113184)