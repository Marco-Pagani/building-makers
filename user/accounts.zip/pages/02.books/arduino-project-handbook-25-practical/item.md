---
title: Arduino Project Handbook: 25 Practical Projects to Get You Started
taxonomy:
	author: Mark Geddes
	pubdate: 2016
	audience: College/University,Libraries,General
	expertise: Beginner
---
## Arduino Project Handbook: 25 Practical Projects to Get You Started
### By Mark Geddes
UF Lib - TJ223.P76

**Publication Date:** 2016

**Expertise Level:** Beginner

**Intended Audience:** College/University,Libraries,General

**ISBN:** 978-1593276904

[Amazon Link](https://www.amazon.com/Arduino-Project-Handbook-Practical-Projects/dp/1593276907/ref=sr_1_1?s=books&ie=UTF8&qid=1541656366&sr=1-1&keywords=arduino+project+handbook&dpID=51sLZyL00IL&preST=_SX218_BO1,204,203,200_QL40_&dpSrc=srch)

[Worldcat Link](http://www.worldcat.org/oclc/913335237)