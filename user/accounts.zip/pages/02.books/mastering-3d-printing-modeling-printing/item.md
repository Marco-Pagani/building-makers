---
title: Mastering 3D printing : modeling, printing, and prototyping with reprap-style 3D printers
taxonomy:
	author: Joan C.,Horvath
	pubdate: 2014
	audience: 
	expertise: 
---
## Mastering 3D printing : modeling, printing, and prototyping with reprap-style 3D printers
### By Joan C.,Horvath

**Publication Date:** 2014

**ISBN:** 1484200268 :