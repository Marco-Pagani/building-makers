---
title: Macramé for home decor : 40 stunning projects for stylish decorating
taxonomy:
	author: Samantha,Grenier
	pubdate: 2019
	audience: General
	expertise: Advanced
---
## Macramé for home decor : 40 stunning projects for stylish decorating
### By Samantha,Grenier
The book starts with basic lessons on macrame and the basic toolkit and extends to 40 projects of varying complexity. Each project has detailed and illustrated step-by-step instructions. Each project is both decorative and useful for household and domestic purposes. Projects include many different types of home decor, plant hangers, wall hangings and mats

**Publication Date:** 2019

**Expertise Level:** Advanced

**Intended Audience:** General

**ISBN:** 978-1-56523-951-7 1-56523-951-2

[Amazon Link](https://www.amazon.com/Macrame-Home-Decor-Step-Step/dp/1565239512/ref=sr_1_1?keywords=Macram%C3%A9+for+home+decor+%3A+40+stunning+projects+for+stylish+decorating&qid=1570112480&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/macrame-for-home-decor-40-stunning-projects-for-stylish-decorating/oclc/1036786995&referer=brief_results)