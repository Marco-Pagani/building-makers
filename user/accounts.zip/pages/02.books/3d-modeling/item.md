---
title: 3D Modeling
taxonomy:
	author: Theo,Zizka
	pubdate: 2014
	audience: 
	expertise: 
---
## 3D Modeling
### By Theo,Zizka

**Publication Date:** 2014

**ISBN:** 978-1-63137-812-6