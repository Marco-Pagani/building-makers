---
title: Wearable Computing: From Modeling to Implementation of Wearable Systems Based on Body Sensor Networks
taxonomy:
	author: Giancarlo Fortino,Raffaele Gravina,Stefano Galzarano
	pubdate: 2018
	audience: College/University,General
	expertise: Advanced
---
## Wearable Computing: From Modeling to Implementation of Wearable Systems Based on Body Sensor Networks
### By Giancarlo Fortino,Raffaele Gravina,Stefano Galzarano

**Publication Date:** 2018

**Expertise Level:** Advanced

**Intended Audience:** College/University,General

**ISBN:** 978-1118864579

[Amazon Link](https://www.amazon.com/Wearable-Computing-Modeling-Implementation-Networks-ebook/dp/B07C1DV3Y4)