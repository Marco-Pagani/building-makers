---
title: '3D animation for the raw beginner using Autodesk Maya 2nd edition'
taxonomy:
    pubdate:
        - '2019'
---

## 3D animation for the raw beginner using Autodesk Maya 2nd edition
### By Roger King

**Publication Date:** 2019

**ISBN:** 0-8153-8878-0