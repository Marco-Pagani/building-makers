---
title: Practical Arduino
taxonomy:
	author: Jonathan Oxer,Hugh Blemings
	pubdate: 2009
	audience: College/University,General,Libraries
	expertise: Intermediate,Advanced
---
## Practical Arduino
### By Jonathan Oxer,Hugh Blemings
UF Library - QA76.76.O63O93 2009

**Publication Date:** 2009

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** College/University,General,Libraries

**ISBN:** 978-1430224778

[Amazon Link](https://www.amazon.com/Practical-Arduino-Projects-Hardware-Technology/dp/1430224770)