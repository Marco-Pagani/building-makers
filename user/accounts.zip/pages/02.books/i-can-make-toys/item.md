---
title: I can make toys
taxonomy:
	author: Emily,Reid
	pubdate: 2016
	audience: K-12
	expertise: Beginner
---
## I can make toys
### By Emily,Reid
This book is full of simple and fun crafts using your recyclables and other household materials to make toys.  Projects you will find include a sock puppet a kite, and a board game.  Each project includes a materials list and colorful instructions, as well as how to use the toy once it's finished.

**Publication Date:** 2016

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-4777-5568-6 1-4777-5568-3 978-1-4777-5645-4 1-4777-5645-0

[Amazon Link](https://www.amazon.com/Can-Make-Toys-Makerspace-Projects/dp/1477756450/ref=sr_1_1?keywords=I+can+make+toys+Reid&qid=1575300987&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/i-can-make-toys/oclc/922305640&referer=brief_results)