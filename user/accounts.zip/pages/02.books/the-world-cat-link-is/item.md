---
title: "The World Cat link is not available for this book."""
taxonomy:
	author: https://www.amazon.com/Vacation-Crafting-Easy-Follow-Find/dp/1641240172/ref=sr_1_1?keywords=Vacation+crafting+%3A+150%2B+summer+camp+projects+for+boys+%26+girls+to+make&qid=1570112558&s=gateway&sr=8-1
	pubdate: 
	audience: 
	expertise: 
---
## "The World Cat link is not available for this book."""
### By https://www.amazon.com/Vacation-Crafting-Easy-Follow-Find/dp/1641240172/ref=sr_1_1?keywords=Vacation+crafting+%3A+150%2B+summer+camp+projects+for+boys+%26+girls+to+make&qid=1570112558&s=gateway&sr=8-1

**ISBN:** The book contains 150 projects to make over summer vacation. Projects are categorized by the basic material they use like seashells, plastic lace, strings, hemp etc. Every project has a description and list of materials required, followed by detailed instructions. The book has colorful and instructive illustrations to accompany the instructions. The highlighted text makes for easy reading for K-12 students.