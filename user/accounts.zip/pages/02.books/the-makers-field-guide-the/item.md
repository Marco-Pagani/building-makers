---
title: The maker's field guide : the definitive guide to making anything imaginable
taxonomy:
	author: Christopher,Armstrong
	pubdate: 2019
	audience: 
	expertise: 
---
## The maker's field guide : the definitive guide to making anything imaginable
### By Christopher,Armstrong

**Publication Date:** 2019

**ISBN:** 978-1-73254-550-2 1-73254-550-2