---
title: Mobile Technology and Academic Libraries: Innovative Services for Research and Learning
taxonomy:
	author: Robin Canuel,Chad Crichton
	pubdate: 2017
	audience: Libraries,College/University
	expertise: Intermediate,Advanced
---
## Mobile Technology and Academic Libraries: Innovative Services for Research and Learning
### By Robin Canuel,Chad Crichton

**Publication Date:** 2017

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** Libraries,College/University

**ISBN:** 978-0838988794

[Amazon Link](https://www.amazon.com/Mobile-Technology-Academic-Libraries-Innovative/dp/0838988792/ref=sr_1_1?ie=UTF8&qid=1543369094&sr=8-1&keywords=mobile+technology+and+academic+libraries)