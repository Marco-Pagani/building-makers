---
title: Master your craft : strategies for designing, making, and selling artisan work
taxonomy:
	author: Tien,Chiu
	pubdate: 2016
	audience: General
	expertise: Beginner
---
## Master your craft : strategies for designing, making, and selling artisan work
### By Tien,Chiu
"""Master your craft"" is designed for those who want to share their art with the world and make a profit doing so.  It guides you through the process of brainstorming your designs and self evaluating your work, and includes tips from artisans from a variety of crafts who have created businesses from their artwork."

**Publication Date:** 2016

**Expertise Level:** Beginner

**Intended Audience:** General

**ISBN:** 0-7643-5145-1

[Amazon Link](https://www.amazon.com/Master-Your-Craft-Strategies-Designing/dp/0764351451/ref=sr_1_1?keywords=Master+your+craft+%3A+strategies+for+designing%2C+making%2C+and+selling+artisan+work&qid=1569856741&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/master-your-craft-strategies-for-designing-making-and-selling-artisan-work/oclc/958280165&referer=brief_results)