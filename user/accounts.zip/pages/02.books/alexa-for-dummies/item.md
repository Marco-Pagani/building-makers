---
title: Alexa for Dummies.
taxonomy:
	author: Paul; ProQuest (Firm),TA/TK; McFedries,Dummies
	pubdate: 2018
	audience: General
	expertise: Beginner
---
## Alexa for Dummies.
### By Paul; ProQuest (Firm),TA/TK; McFedries,Dummies
Alexa for Dummies is your guide to understanding and using your Alexa to enhance your home.  It covers the basic functions of Alexa as well as adding to her skills and connecting her to smart home devices.

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** General

**ISBN:** 978-1-119-56581-9

[Amazon Link](https://www.amazon.com/Alexa-Dummies-Paul-McFedries/dp/1119565863/ref=sr_1_1?keywords=Alexa+for+Dummies.&qid=1575492538&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/alexa-for-dummies/oclc/1083268734&referer=brief_results)