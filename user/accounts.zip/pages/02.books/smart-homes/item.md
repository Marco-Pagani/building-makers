---
title: Smart homes
taxonomy:
	author: John,; Haslam,Max,Wainewright
	pubdate: 2019
	audience: K-12
	expertise: Beginner
---
## Smart homes
### By John,; Haslam,Max,Wainewright
Using Scratch 3, a free online program for coding, this book explains some of the technologies used in smart home technologies, like cameras, voice control, and alarms using colorful diagrams and step by step projects.

**Publication Date:** 2019

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-5263-0875-7 1-5263-0875-4

[Amazon Link](https://www.amazon.com/Scratch-Code-Smart-Homes-Challenge/dp/0778765687/ref=sr_1_1?keywords=smart+homes+wainewright+max&qid=1575245907&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/scratch-code-smart-homes/oclc/1090700944&referer=brief_results)