---
title: Internet of Things (IoT): Technologies, Applications, Challenges, and Solutions
taxonomy:
	author: BK Tripathy,J Anuradha
	pubdate: 2017
	audience: College/University,General
	expertise: Intermediate,Advanced
---
## Internet of Things (IoT): Technologies, Applications, Challenges, and Solutions
### By BK Tripathy,J Anuradha
The text is more of a collection about Wearables and the Internet of Things rather than an instructional text. The book covers a diverse range of technologies and the social implications.

**Publication Date:** 2017

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** College/University,General

**ISBN:** 978-1138035003

[Amazon Link](https://www.amazon.com/Internet-Things-IoT-Technologies-Applications/dp/1138035009/ref=sr_1_1?ie=UTF8&qid=1543368706&sr=8-1&keywords=internet+of+things+technologies+applications+challenges+and+solutions)