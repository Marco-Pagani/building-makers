---
title: 25 projects for art explorers
taxonomy:
	author: Christine,Kirker
	pubdate: 2018
	audience: K-12
	expertise: Beginner
---
## 25 projects for art explorers
### By Christine,Kirker
The book provides instructions on different art projects using a variety of materials and techniques. Each project is presented through an example of a picture book. Children see how it is used in the text. It is then followed by a list of materials required and instructions. The illustrations are imaginative and allow children to think of art as an imaginative and applied process. 

**Publication Date:** 2018

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 0-8389-1739-9 978-0-8389-1739-8

[Amazon Link](https://www.amazon.com/Projects-Art-Explorers-Christine-Kirker/dp/0838917399/ref=sr_1_1?keywords=25+projects+for+art+explorers&qid=1570114504&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/25-projects-for-art-explorers/oclc/1040677777&referer=brief_results)