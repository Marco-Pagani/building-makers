---
title: How to show & sell your crafts : how to build your craft business at home, online, and in the marketplace
taxonomy:
	author: Torie.,Jayne
	pubdate: 2014
	audience: 
	expertise: 
---
## How to show & sell your crafts : how to build your craft business at home, online, and in the marketplace
### By Torie.,Jayne

**Publication Date:** 2014

**ISBN:** 978-1-250-04472-3 1-250-04472-3