---
title: Homeskills. an introduction to sawing, drilling, shaping & joining wood.
taxonomy:
	author: 
	pubdate: 2013
	audience: 
	expertise: 
---
## Homeskills. an introduction to sawing, drilling, shaping & joining wood.

**Publication Date:** 2013

**ISBN:** 1591865794 (softcover)