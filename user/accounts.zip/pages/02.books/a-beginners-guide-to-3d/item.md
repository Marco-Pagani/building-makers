---
title: A beginner's guide to 3D modeling : a guide to Autodesk Fusion 360
taxonomy:
	author: Cameron,Coward
	pubdate: 2019
	audience: 
	expertise: 
---
## A beginner's guide to 3D modeling : a guide to Autodesk Fusion 360
### By Cameron,Coward

**Publication Date:** 2019

**ISBN:** 978-1-59327-926-4 1-59327-926-4