---
title: Outdoor wood projects : 24 projects you can build in a weekend
taxonomy:
	author: Steve.,Cory
	pubdate: 2014
	audience: 
	expertise: 
---
## Outdoor wood projects : 24 projects you can build in a weekend
### By Steve.,Cory

**Publication Date:** 2014

**ISBN:** 978-1-62113-808-2 1-62113-808-9