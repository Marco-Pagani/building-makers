---
title: Make : 3D printing
taxonomy:
	author: Brian,Anna Kaziunas; Jepson,France
	pubdate: 2014
	audience: 
	expertise: 
---
## Make : 3D printing
### By Brian,Anna Kaziunas; Jepson,France

**Publication Date:** 2014

**ISBN:** 1-4571-8293-9