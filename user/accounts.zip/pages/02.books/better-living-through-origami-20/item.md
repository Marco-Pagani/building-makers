---
title: Better living through origami : 20 creative paper projects for a beautiful home
taxonomy:
	author: Inc.,; OverDrive,Kenneth,; Veenenbos,Nellianna,Van den Baard
	pubdate: 2018
	audience: General
	expertise: Beginner,Intermediate,Advanced
---
## Better living through origami : 20 creative paper projects for a beautiful home
### By Inc.,; OverDrive,Kenneth,; Veenenbos,Nellianna,Van den Baard
If you have been looking for a way to breathe creativity into your home decor, here is your answer.  It boasts 20 paper projects integrating elements of origami and general crafting, ranging in difficulty and complexity, easy to follow diagrams, instructions, and photographs.

**Publication Date:** 2018

**Expertise Level:** Beginner,Intermediate,Advanced

**Intended Audience:** General

**ISBN:** "	9781446376683 1446376680"

[Amazon Link](https://www.amazon.com/Better-Living-Through-Origami-Beautiful/dp/1446307123/ref=sr_1_1?keywords=Better+living+through+origami+%3A+20+creative+paper+projects+for+a+beautiful+home&qid=1572463464&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/better-living-through-origami-20-creative-paper-projects-for-a-beautiful-home/oclc/1055266998&referer=brief_results)