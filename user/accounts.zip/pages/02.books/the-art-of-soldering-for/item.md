---
title: The art of soldering for jewelry makers : techniques and projects
taxonomy:
	author: Wing Mun,Devenney
	pubdate: 2013
	audience: General
	expertise: Beginner,Intermediate
---
## The art of soldering for jewelry makers : techniques and projects
### By Wing Mun,Devenney
This book, aimed at people interested in making unique jewelry using soldering,  explains soldering materials, tools, techniques, and safety before diving into more complex projects like cufflinks, bangles, and brooches.

**Publication Date:** 2013

**Expertise Level:** Beginner,Intermediate

**Intended Audience:** General

**ISBN:** 978-1-4380-0263-7 1-4380-0263-7

[Amazon Link](https://www.amazon.com/Art-Soldering-Jewelry-Makers-Techniques/dp/1438002637/ref=sr_1_1?keywords=The+art+of+soldering+for+jewelry+makers+%3A+techniques+and+projects&qid=1575301417&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/art-of-soldering-for-jewellery-makers-techniques-and-projects/oclc/861725457&referer=brief_results)