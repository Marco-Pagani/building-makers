---
title: Advanced Raspberry Pi: Raspbian Linux and GPIO Integration
taxonomy:
	author: Warren,Gay
	pubdate: 2018
	audience: General
	expertise: Intermediate,Advanced
---
## Advanced Raspberry Pi: Raspbian Linux and GPIO Integration
### By Warren,Gay
Advanced Raspberry Pi: Raspbian Linux and GPIO Integration introduces you to Raspberry Pi and provides detailed explanations of the functions of your Raspberry Pi, simple and advanced.

**Publication Date:** 2018

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** General

**ISBN:** 978-1-4842-3948-3

[Amazon Link](https://www.amazon.com/Advanced-Raspberry-Pi-Raspbian-Integration/dp/1484239474/ref=sr_1_3?keywords=Advanced+Raspberry+Pi%3A+Raspbian+Linux+and+GPIO+Integration&qid=1570651464&sr=8-3)

[Worldcat Link](https://www.worldcat.org/title/advanced-raspberry-pi-raspbian-linux-and-gpio-integration/oclc/1117843596&referer=brief_results)