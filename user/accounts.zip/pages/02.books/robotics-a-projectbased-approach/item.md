---
title: Robotics : a project-based approach
taxonomy:
	author: Mike,Lakshmi; Tanamachi,Valerie Haynes; Prayaga,Sam; Perry,Garvey
	pubdate: 2015
	audience: 
	expertise: 
---
## Robotics : a project-based approach
### By Mike,Lakshmi; Tanamachi,Valerie Haynes; Prayaga,Sam; Perry,Garvey

**Publication Date:** 2015

**ISBN:** 1-305-27102-5