---
title: The Invent to Learn guide to 3D printing in the classroom : recipes for success
taxonomy:
	author: Norma,Sara; Thornburg,David D.; Armstrong,Thornburg
	pubdate: 2014
	audience: 
	expertise: 
---
## The Invent to Learn guide to 3D printing in the classroom : recipes for success
### By Norma,Sara; Thornburg,David D.; Armstrong,Thornburg

**Publication Date:** 2014

**ISBN:** 0-9891511-4-X