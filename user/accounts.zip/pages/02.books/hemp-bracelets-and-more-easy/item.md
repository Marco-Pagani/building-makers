---
title: Hemp bracelets and more : easy instructions for more than 20 designs
taxonomy:
	author: Suzanne.,McNeill
	pubdate: 2016
	audience: K-12
	expertise: Beginner
---
## Hemp bracelets and more : easy instructions for more than 20 designs
### By Suzanne.,McNeill
The book provides instruction on hemp bracelet projects with detailed, illustrated instructions on overhand knots, half-hitch knot, half knot, square knot and josephine knot. It starts with different ideas for bracelets and strategies for projects and knitting.

**Publication Date:** 2016

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-4972-0057-9 1-4972-0057-1

[Amazon Link](https://www.amazon.com/Tandy-Leather-Hemp-Bracelets-61964-00/dp/1497200571/ref=sr_1_1?keywords=Hemp+bracelets+and+more+%3A+easy+instructions+for+more+than+20+designs&qid=1570112789&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/hemp-bracelets-and-more-easy-instructions-for-more-than-20-designs/oclc/929585526&referer=brief_results)