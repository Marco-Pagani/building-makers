---
title: Arduino Sketches: Tools and Techniques for Programming Wizardry
taxonomy:
	author: James A. Langbridge
	pubdate: 2015
	audience: College/University,Libraries
	expertise: Intermediate,Advanced
---
## Arduino Sketches: Tools and Techniques for Programming Wizardry
### By James A. Langbridge
UF Library Catalog - TJ223.P76L36 2015

**Publication Date:** 2015

**Expertise Level:** Intermediate,Advanced

**Intended Audience:** College/University,Libraries

**ISBN:** 978-1118919606

[Amazon Link](https://www.amazon.com/Arduino-Sketches-Techniques-Programming-Wizardry/dp/1118919602)