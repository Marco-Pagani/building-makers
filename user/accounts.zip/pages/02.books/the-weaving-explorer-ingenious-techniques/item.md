---
title: The weaving explorer : ingenious techniques, accessible tools & creative projects with yarn, paper, wire & more
taxonomy:
	author: Gwen,; Steege,Deborah,Jarchow
	pubdate: 2019
	audience: 
	expertise: 
---
## The weaving explorer : ingenious techniques, accessible tools & creative projects with yarn, paper, wire & more
### By Gwen,; Steege,Deborah,Jarchow

**Publication Date:** 2019

**ISBN:** 978-1-63586-028-3 1-63586-028-8

[Amazon Link](https://www.amazon.com/Weaving-Explorer-Ingenious-Techniques-Accessible/dp/1635860288/ref=sr_1_1?keywords=The+weaving+explorer+%3A+ingenious+techniques%2C+accessible+tools+%26+creative+projects+with+yarn%2C+paper%2C+wire+%26+more&qid=1570112226&s=gateway&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/weaving-explorer-ingenious-techniques-accessible-tools-creative-projects-with-yarn-paper-wire-more/oclc/1113055234&referer=brief_results)