---
title: Arduino Playground: Geeky Projects for the Experienced Maker
taxonomy:
	author: Warren Andrews
	pubdate: 2017
	audience: College/University,General,Libraries
	expertise: Advanced,Intermediate
---
## Arduino Playground: Geeky Projects for the Experienced Maker
### By Warren Andrews
UF Library - TJ223.P76

**Publication Date:** 2017

**Expertise Level:** Advanced,Intermediate

**Intended Audience:** College/University,General,Libraries

**ISBN:** 978-1593277444

[Amazon Link](https://www.amazon.com/Arduino-Playground-Geeky-Projects-Experienced/dp/159327744X/ref=sr_1_1?s=books&ie=UTF8&qid=1541655140&sr=1-1&keywords=Arduino+Playground&dpID=51HyAc8oCoL&preST=_SX218_BO1,204,203,200_QL40_&dpSrc=srch)