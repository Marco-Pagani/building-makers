---
title: Cool woodworking projects
taxonomy:
	author: Rebecca,Felix
	pubdate: 2017
	audience: K-12
	expertise: Beginner
---
## Cool woodworking projects
### By Rebecca,Felix
This book is designed for teaching junior makers about wood working, using simple language and colorful images.  It includes an introduction to woodworking and 5 projects to build your new skills.

**Publication Date:** 2017

**Expertise Level:** Beginner

**Intended Audience:** K-12

**ISBN:** 978-1-68078-130-4 1-68078-130-8

[Amazon Link](https://www.amazon.com/Cool-Woodworking-Projects-Activities-Industrial/dp/1680781308/ref=sr_1_1?keywords=Cool+woodworking+projects+felix&qid=1575758811&sr=8-1)

[Worldcat Link](https://www.worldcat.org/title/cool-woodworking-projects/oclc/1000592007&referer=brief_results)